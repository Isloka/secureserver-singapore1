-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: localhost    Database: aarogyahealthcare
-- ------------------------------------------------------
-- Server version	5.6.49-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `aarogyahealthcare`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `aarogyahealthcare` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `aarogyahealthcare`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(15) NOT NULL,
  `update-date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (3,'admin','photo/1584599437logo.png','admin','arogya@admin','2020-11-01 06:44:56');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adviser`
--

DROP TABLE IF EXISTS `adviser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adviser` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pname` varchar(50) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `sdetail` varchar(50) NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adviser`
--

LOCK TABLES `adviser` WRITE;
/*!40000 ALTER TABLE `adviser` DISABLE KEYS */;
INSERT INTO `adviser` VALUES (1,'photo-1','Monika Bharti ','Adviser..','photo/1602593387monika1.jpg'),(2,'photo-2','Nitish Singh','staff detail','photo/1603133378WhatsApp Image 2020-10-19 at 17.07.26.jpeg'),(3,'photo-3','Ragini Priya','staff detail','photo/1603133423WhatsApp Image 2020-10-19 at 20.20.56.jpeg'),(4,'photo-4','himanshu kumar ','staff detail','photo/1602590949team.png');
/*!40000 ALTER TABLE `adviser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (2,'abhay kumar','suraj12@gmail.com','regarding to project','ggggg');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pname` varchar(10) NOT NULL,
  `photo` text NOT NULL,
  `head` varchar(255) NOT NULL,
  `prgh` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event`
--

LOCK TABLES `event` WRITE;
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` VALUES (1,'photo-1','photo/1603132113WhatsApp Image 2020-10-18 at 20.59.11.jpeg','à¤šà¤¿à¤•à¤¿à¤¤à¥à¤¸à¤¾ à¤¸à¤®à¥à¤¬à¤‚à¤§à¤¿à¤¤ .  ','Integer sollicitudin ligula non enim sodales lacinia nunc ornare. Sewid commodo tempor dapibus. Duis con vallis turpis in tortor voare ri in euismod varius nullam feugiat ultrices. Sed condimentum est libero, ali. Phasellus scelerisque nisl non ullamcorpe'),(2,'photo-2','photo/1603131451study.jpg','à¤¶à¤¿à¤•à¥à¤·à¤¾ à¤¸à¤®à¥à¤¬à¤‚à¤§à¤¿à¤¤  . ','iiiInteger sollicitudin ligula non enim sodales lacinia nunc ornare. Sewid commodo tempor dapibus. Duis con vallis turpis in tortor voare ri in euismod varius nullam feugiat ultrices. Sed condimentum est libero, ali. Phasellus scelerisque nisl non ullamco'),(3,'photo-3','photo/1603131698bhojan.jpg','à¤­à¥‹à¤œà¤¨ à¤¸à¤®à¥à¤¬à¤‚à¤§à¤¿à¤¤ . ','Integer sollicitudin ligula non enim sodales lacinia nunc ornare. Sewid commodo tempor dapibus. Duis con vallis turpis in tortor voare ri in euismod varius nullam feugiat ultrices. Sed condimentum est libero, ali. Phasellus scelerisque nisl non ullamcorpe'),(4,'photo-4','photo/1603131718viksharopan.jpg','à¤µà¥ƒà¤•à¥à¤·à¤¾à¤°à¥‹à¤ªà¤£ à¤¸à¤®à¥à¤¬à¤‚à¤§à¤¿à¤¤ ','Integer sollicitudin ligula non enim sodales lacinia nunc ornare. Sewid commodo tempor dapibus. Duis con vallis turpis in tortor voare ri in euismod varius nullam feugiat ultrices. Sed condimentum est libero, ali. Phasellus scelerisque nisl non ullamcorpe'),(5,'photo-5','photo/1603131807healthcare-symbol.png','à¤®à¤²à¥à¤Ÿà¥€à¤¸à¥à¤ªà¥‡à¤¶à¤²à¥€à¤Ÿà¥€ à¤…à¤¸à¥à¤ªà¤¤à¤¾à¤² ','Integer sollicitudin ligula non enim sodales lacinia nunc ornare. Sewid commodo tempor dapibus. Duis con vallis turpis in tortor voare ri in euismod varius nullam feugiat ultrices. Sed condimentum est libero, ali. Phasellus scelerisque nisl non ullamcorpe'),(6,'photo-6','photo/1603132207medicine.jpg','à¤…à¤¸à¥â€à¤ªà¤¤à¤¾à¤² à¤à¤µà¤‚ à¤¦à¤µà¤¾  ','Integer sollicitudin ligula non enim sodales lacinia nunc ornare. Sewid commodo tempor dapibus. Duis con vallis turpis in tortor voare ri in euismod varius nullam feugiat ultrices. Sed condimentum est libero, ali. Phasellus scelerisque nisl non ullamcorpe');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `frenchisee`
--

DROP TABLE IF EXISTS `frenchisee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frenchisee` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `relign` varchar(30) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `pin` int(8) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `frenchisee`
--

LOCK TABLES `frenchisee` WRITE;
/*!40000 ALTER TABLE `frenchisee` DISABLE KEYS */;
INSERT INTO `frenchisee` VALUES (3,'suraj kumar','suraj12@gmail.com',2147483647,'hindu','patna','bihar',800001,'sadhanapuri'),(4,'','',0,'','','',0,'');
/*!40000 ALTER TABLE `frenchisee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photogallery`
--

DROP TABLE IF EXISTS `photogallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photogallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `photo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photogallery`
--

LOCK TABLES `photogallery` WRITE;
/*!40000 ALTER TABLE `photogallery` DISABLE KEYS */;
INSERT INTO `photogallery` VALUES (1,'photo-1','photo/1603132819WhatsApp Image 2020-10-18 at 18.16.28 (1).jpeg'),(3,'photo-2','photo/1603132883WhatsApp Image 2020-10-18 at 18.16.29 (1).jpeg'),(4,'photo-3 ','photo/1603132857WhatsApp Image 2020-10-18 at 18.16.29.jpeg'),(5,'photo-4','photo/1603132872WhatsApp Image 2020-10-18 at 18.16.33 (1).jpeg'),(6,'photo-5','photo/1603132925WhatsApp Image 2020-10-18 at 18.16.38.jpeg'),(7,'photo-6','photo/1603132840WhatsApp Image 2020-10-18 at 18.16.28.jpeg'),(8,'photo-7','photo/1603132900WhatsApp Image 2020-10-18 at 18.16.37 (1).jpeg'),(9,'photo-8','photo/1603132942WhatsApp Image 2020-10-18 at 18.16.40.jpeg'),(10,'photo-9','photo/1603132913WhatsApp Image 2020-10-18 at 18.16.37.jpeg'),(11,'photo-10','photo/1584601161pic10.jpg'),(12,'photo-11','photo/1584601175pic6.jpg'),(13,'photo-12','photo/1584601189pic1.jpg');
/*!40000 ALTER TABLE `photogallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` text NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider`
--

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` VALUES (2,'photo/1584602320slider2.jpg','photo-1'),(3,'photo/1584602991logo.png','photo-2'),(4,'photo/1584602979slider2.jpg','photo-3 ');
/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subdmin`
--

DROP TABLE IF EXISTS `subdmin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subdmin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subdmin`
--

LOCK TABLES `subdmin` WRITE;
/*!40000 ALTER TABLE `subdmin` DISABLE KEYS */;
INSERT INTO `subdmin` VALUES (2,'Softart','soft','soft123','photo/1546064066NAC 2 (1).png','2018-12-29 11:44:26');
/*!40000 ALTER TABLE `subdmin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supporter`
--

DROP TABLE IF EXISTS `supporter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supporter` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pname` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `sdetail` varchar(255) NOT NULL,
  `photo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supporter`
--

LOCK TABLES `supporter` WRITE;
/*!40000 ALTER TABLE `supporter` DISABLE KEYS */;
INSERT INTO `supporter` VALUES (1,'photo-1','Sanjay kumar   ','Staff Detail','photo/1602592084team.png'),(2,'photo-2','suraj kumar   ','staff detail','photo/1602592096team.png'),(3,'photo-3','abhishek kumar ','staff detail','photo/1602592118team.png'),(4,'photo-4','himanshu kumar ','staff detail','photo/1602592130team.png'),(5,'photo-5','ragini sharma ','staff detail','photo/1602592142team.png'),(6,'photo-6','sakshi verma ','staff detail','photo/1602592155team.png'),(7,'photo-7','sandhya kumari ','staff detail','photo/1602592167team.png'),(8,'photo-8','sanjana kumari ','staff detail','photo/1602592178team.png');
/*!40000 ALTER TABLE `supporter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `team` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pname` varchar(255) NOT NULL,
  `sname` varchar(255) NOT NULL,
  `sdetail` varchar(50) NOT NULL,
  `photo` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (2,'photo-1','Govind Pandey      ','Business Developer','photo/1602654631g.jpg'),(3,'photo-2','Kuhasa krity      ','M.H','photo/1602654640k.jpg'),(4,'photo-3','Pritam kr Ravi     ','M.D','photo/1602654649p.jpg'),(5,'photo-4','himanshu kumar ','staff detail','photo/1602591274team.png');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'aarogyahealthcare'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-09  7:20:07
