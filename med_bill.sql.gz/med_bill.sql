-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: localhost    Database: med_bill
-- ------------------------------------------------------
-- Server version	5.6.49-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `med_bill`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `med_bill` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `med_bill`;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `invoice` int(10) NOT NULL,
  `itemid` int(6) NOT NULL,
  `itemprice` float NOT NULL,
  `disc` int(3) NOT NULL,
  `qnty` int(5) NOT NULL,
  `free` int(11) NOT NULL,
  `date` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (1,3,24,120,40,4,0,'02:Jan:2019'),(2,4,19,225,0,2,0,'04:Feb:2019');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `catname` varchar(50) NOT NULL,
  `hsncode` int(10) NOT NULL,
  `company` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (41,'Chawanprash',12001,'Daber'),(42,'kohinoor',7,'xxx');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (20,'Daber'),(21,'xxx');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `gstno` varchar(255) NOT NULL,
  `dlno` varchar(30) NOT NULL,
  `address` varchar(200) NOT NULL,
  `invoice` int(8) NOT NULL,
  `date` int(2) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `total` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (105,'keshab','9685968574','10AUWPP4335R1XT','33A/32B','bs',3,2,1,19,0),(106,'Daber','7631759812','10AUWPP4335R1XT','44/44A','juu',4,4,2,19,0);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dailytrans`
--

DROP TABLE IF EXISTS `dailytrans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dailytrans` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `invoice` int(10) NOT NULL,
  `amount` float NOT NULL,
  `date` int(2) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `RestAmount` int(11) NOT NULL,
  `paid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=396 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dailytrans`
--

LOCK TABLES `dailytrans` WRITE;
/*!40000 ALTER TABLE `dailytrans` DISABLE KEYS */;
INSERT INTO `dailytrans` VALUES (391,1,126.72,30,12,2018,26,100),(392,2,223.72,30,12,2018,123,100),(393,3,274.5,2,1,2019,254,20),(394,4,429.3,4,2,2019,22,407),(395,4,429.3,4,2,2019,22,407);
/*!40000 ALTER TABLE `dailytrans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dellar`
--

DROP TABLE IF EXISTS `dellar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dellar` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `gstno` varchar(30) NOT NULL,
  `mob1` varchar(12) NOT NULL,
  `mob2` varchar(12) NOT NULL,
  `address` varchar(150) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dellar`
--

LOCK TABLES `dellar` WRITE;
/*!40000 ALTER TABLE `dellar` DISABLE KEYS */;
INSERT INTO `dellar` VALUES (35,'Softart','10AUWPP4335R1XT','8765129082','7651098761','Nalanda','info@gmail.com'),(36,'Medical Hall','10AUWPP4335R1XU','8974129872','0','Patna','mhall@gmail.com'),(37,'prabhakar','10AUWPP4335R1XT','7894561230','0','PATNA','g@gmail.com');
/*!40000 ALTER TABLE `dellar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `freegift`
--

DROP TABLE IF EXISTS `freegift`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `freegift` (
  `free` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `freegift`
--

LOCK TABLES `freegift` WRITE;
/*!40000 ALTER TABLE `freegift` DISABLE KEYS */;
/*!40000 ALTER TABLE `freegift` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hsncode`
--

DROP TABLE IF EXISTS `hsncode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hsncode` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(15) NOT NULL,
  `gst` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hsncode`
--

LOCK TABLES `hsncode` WRITE;
/*!40000 ALTER TABLE `hsncode` DISABLE KEYS */;
INSERT INTO `hsncode` VALUES (89,'12001',6),(91,'100007',10);
/*!40000 ALTER TABLE `hsncode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `mm` int(2) NOT NULL,
  `my` int(4) NOT NULL,
  `em` int(2) NOT NULL,
  `ey` int(4) NOT NULL,
  `cat` varchar(50) NOT NULL,
  `com` varchar(50) NOT NULL,
  `hsncode` int(20) NOT NULL,
  `cp` float NOT NULL,
  `sp` float NOT NULL,
  `mrp` float NOT NULL,
  `qnty` int(5) NOT NULL,
  `free` int(11) NOT NULL,
  `dellarid` varchar(30) NOT NULL,
  `amount` float NOT NULL,
  `batchid` varchar(30) NOT NULL,
  `date` int(2) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (18,'Ahawanprash',2,2018,12,2019,'Chawanprash','Daber',12001,123,125,130,449,0,'Softart',15129,'123',20,12,2018),(19,'Shakti',2,2018,6,2018,'Chawanprash','Daber',12001,220,225,240,107,0,'Softart',28380,'1567',20,12,2018),(20,'Shakti',4,2018,5,2015,'Chawanprash','Daber',12001,123,124,130,197,200,'Medical Hall',24600,'1234',26,12,2018),(24,'condom',6,2019,6,2020,'kohinoor','xxx',12001,110,120,125,41,45,'prabhakar',4950,'12345',2,1,2019);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `userid` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'patelpharma','sac@ppbs');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `gstno` varchar(50) NOT NULL,
  `pan` varchar(24) NOT NULL,
  `email` varchar(40) NOT NULL,
  `address` varchar(150) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'Patel Fanma','xxxxxxxxxxxxx','xxxxxxxxxxxxxx','xxxxxxxxxxxxxxx','BiharSharif','Nalanda','Bihar');
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `dellarid` varchar(30) NOT NULL,
  `totalamount` float NOT NULL,
  `date` int(2) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (104,'Softart',15129,20,12,2018),(105,'Softart',14760,20,12,2018),(106,'Softart',29520,20,12,2018),(107,'Softart',28380,20,12,2018),(108,'Medical Hall',24600,26,12,2018),(109,'prabhakar',220,2,1,2019),(110,'prabhakar',220,2,1,2019),(111,'prabhakar',330,2,1,2019),(112,'prabhakar',4950,2,1,2019),(113,'..Select..',2530,2,1,2019),(114,'Softart',2530,2,1,2019);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'med_bill'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-09  7:20:08
