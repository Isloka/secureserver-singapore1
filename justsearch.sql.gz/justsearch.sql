-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: localhost    Database: justsearch
-- ------------------------------------------------------
-- Server version	5.6.49-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `justsearch`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `justsearch` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `justsearch`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'softart','admin','2019-01-29 10:25:03');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `alternate_contact` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `site` varchar(100) NOT NULL,
  `image1` varchar(255) NOT NULL,
  `image2` varchar(250) NOT NULL,
  `image3` varchar(250) NOT NULL,
  `open_time` time NOT NULL,
  `services` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (1,'coaching','NAC',8797856985,8574963214,'nacedu@gmail.com','naceduworld.org.in','images/company1548757576nac certificat2.jpg','images/company1548757576nac certificat2.jpg','images/company1548757576nac certificat2.jpg','09:00:00','Coaching Classes','Patna','2019-01-29 10:26:16'),(2,'pharmacy','Patel Pharma',9865472596,7845962541,'patelpharma@gmail.com','http://www.patelpharma.com','images/company1548762723s.png','images/company1548762723sac logo png.png','images/company1548762723sac logo 1.jpg','08:00:00','Medicine ,Checkup','Patna','2019-01-29 11:52:03'),(3,'tiles','Tulsiyan Interprises',9865472596,8574123698,'tulsiyan@gmail.com','tulsiayan.com','images/company/1548231191tulsian_img19.jpg','images/company/1548231191tulsian_img3.jpg','images/company/1548231191tulsian_img1.jpg','09:00:00','Tiles','Hajipur','2019-01-23 08:13:11'),(4,'cab','Taxi',5896896532,8574123698,'taxi@gmail.com','taxi.com','images/company1548757137enjoy_cab.jpg','images/company1548757137taxi.jpg','images/company1548757137taxi1.jpg','07:01:00','Cab Facility, Marriage Booking, Furniture Loading','Patna,Bihar','2019-01-29 10:18:57'),(5,'hotel','Hotel Manish',8797856985,8574963214,'hotelmanish@gmail.com','hotelmanish.com','images/company/1548757249bedroom_bg.jpg','images/company/1548757249hall1.jpg','images/company/1548757249catering.jpg','06:00:00','Ac & Non-Ac Rooms, Event Booking ,Caterer, Resturant.','Patna','2019-01-29 10:20:49'),(6,'consultancy','Softart Consultancy',8966341331,8574123698,'info@softartconsultancy.com','www.softartconsultancy.com','images/company/1548762201banner_bg.jpg','images/company/1548762201banner_bg1.jpg','images/company/1548762201banner_bg2.png','10:00:00','Web Development, Testing, Designing,etc','Gardanibagh','2019-01-29 11:43:21');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_rating`
--

DROP TABLE IF EXISTS `company_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_rating` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `company_id` int(255) NOT NULL,
  `star` int(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_rating`
--

LOCK TABLES `company_rating` WRITE;
/*!40000 ALTER TABLE `company_rating` DISABLE KEYS */;
INSERT INTO `company_rating` VALUES (1,3,3,'Good Tiles','Good Quality Tiles'),(2,3,4,'Good Tiles','Good'),(3,3,5,'Good Tiles','Nice');
/*!40000 ALTER TABLE `company_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `price` int(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12345680 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (12345678,'iPhone 6s (Space Grey)','<ul style=\"margin:0px;padding:15px;\">\r\n				<li>32 GB ROM |</li>\r\n				<li>11.94 cm (4.7 inch) Retina HD Display</li>\r\n				<li>12MP Rear Camera | 5MP Front Camera</li>\r\n				<li>Apple A9 64-bit processor and Embedded M9 Motion Co-processor</li>\r\n				<li>Brand Warranty of 1 Year</li>\r\n			</ul>	',34000,'apple-iphone-6s.jpeg','0000-00-00 00:00:00','2019-01-19 08:43:04'),(12345679,'iPhone 6s (Silver)','<ul style=\"margin:0px;padding:15px;\">\r\n				<li>32 GB ROM |</li>\r\n				<li>11.94 cm (4.7 inch) Retina HD Display</li>\r\n				<li>12MP Rear Camera | 5MP Front Camera</li>\r\n				<li>Apple A9 64-bit processor and Embedded M9 Motion Co-processor</li>\r\n				<li>Brand Warranty of 1 Year</li>\r\n			</ul>	',30000,'apple-iphone-6.jpeg','0000-00-00 00:00:00','2019-01-19 08:43:04');
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_rating`
--

DROP TABLE IF EXISTS `item_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_rating` (
  `ratingId` int(11) NOT NULL AUTO_INCREMENT,
  `itemId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `ratingNumber` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 = Block, 0 = Unblock',
  PRIMARY KEY (`ratingId`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_rating`
--

LOCK TABLES `item_rating` WRITE;
/*!40000 ALTER TABLE `item_rating` DISABLE KEYS */;
INSERT INTO `item_rating` VALUES (29,2,1,4,'Nice Pharmacy','Good Product','2019-01-29 12:28:25','2019-01-29 12:28:25',1),(30,3,1,4,'Nice Tiles','Good Quality Tiles','2019-01-29 12:35:40','2019-01-29 12:35:40',1),(31,1,1,5,'Good Coaching','Nice','2019-01-29 12:47:14','2019-01-29 12:47:14',1),(32,6,1,5,'Good Consultancy','Good','2019-01-29 12:48:08','2019-01-29 12:48:08',1),(33,6,1,3,'Good Coaching','Nice','2019-01-29 12:48:18','2019-01-29 12:48:18',1),(34,6,1,4,'Good Service','Best Software Development Team','2019-01-29 13:19:30','2019-01-29 13:19:30',1),(35,1,1,4,'Nice','Test','2019-01-30 06:19:02','2019-01-30 06:19:02',1),(36,2,12,1,'Good Service','Test','2019-01-30 07:05:13','2019-01-30 07:05:13',1),(37,1,13,4,'Good Service','Test','2019-01-30 07:12:44','2019-01-30 07:12:44',1),(38,5,13,4,'Good Service','Nice Room','2019-01-30 07:29:49','2019-01-30 07:29:49',1),(39,1,19,1,'Nice ','Test','2019-01-30 07:49:16','2019-01-30 07:49:16',1),(40,3,20,4,'Good Tiles','Test','2019-01-30 08:01:30','2019-01-30 08:01:30',1);
/*!40000 ALTER TABLE `item_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_users`
--

DROP TABLE IF EXISTS `item_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_users` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `contact` (`contact`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_users`
--

LOCK TABLES `item_users` WRITE;
/*!40000 ALTER TABLE `item_users` DISABLE KEYS */;
INSERT INTO `item_users` VALUES (12,'Prabhakar',8709629385,'samirjha05@gmail.com','','Samir@12','image/userpics/1548827528'),(13,'Amit',9876543210,'admin@123','','admin','image/userpics/1548828444'),(15,'Softart',7485968574,'softart@gmail.com','','','image/userpics/1548829761'),(18,'Rahul',8527419630,'rahul@gmail.com','','','image/userpics/1548830805'),(19,'Amar',7894561263,'amarr@gmail.com','','Amar@123','image/userpics/1548830899'),(20,'Keshab Mishra',7418529630,'Keshav@gmail.com','','Keshab@12','image/userpics/1548831381');
/*!40000 ALTER TABLE `item_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'justsearch'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-09  7:20:08
