-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: localhost    Database: jeevansathindia
-- ------------------------------------------------------
-- Server version	5.6.49-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `jeevansathindia`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `jeevansathindia` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `jeevansathindia`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `aid` int(8) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(40) NOT NULL,
  `Password` varchar(60) NOT NULL,
  `Email-Id` varchar(60) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','jvn@pat02','info@softartconsultancy.com');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assisted_services`
--

DROP TABLE IF EXISTS `assisted_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assisted_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assisted_services`
--

LOCK TABLES `assisted_services` WRITE;
/*!40000 ALTER TABLE `assisted_services` DISABLE KEYS */;
INSERT INTO `assisted_services` VALUES (2,'keshab',7689651290,'keshabkumarmishra@gmail.com','patna','2018-12-19 10:44:42'),(3,'keshab',7689651290,'keshab@softartconsultancy.com','patna','2018-12-19 10:46:07');
/*!40000 ALTER TABLE `assisted_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `cust_id` int(50) NOT NULL,
  `ProfileFor` varchar(30) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` varchar(25) NOT NULL,
  `MaritalStatus` varchar(25) NOT NULL,
  `DateOfBirth` varchar(25) NOT NULL,
  `MobileNo` varchar(25) NOT NULL,
  `Religion` varchar(25) NOT NULL,
  `Caste` varchar(25) NOT NULL,
  `SubCaste` varchar(25) NOT NULL,
  `EmailId` varchar(50) NOT NULL,
  `BloodGroup` varchar(25) NOT NULL,
  `BodyColor` varchar(25) NOT NULL,
  `Age` varchar(25) NOT NULL,
  `Height` varchar(25) NOT NULL,
  `Weight` varchar(25) NOT NULL,
  `Diet` varchar(25) NOT NULL,
  `Smoke` varchar(25) NOT NULL,
  `Drink` varchar(25) NOT NULL,
  `Country` varchar(25) NOT NULL,
  `State` varchar(25) NOT NULL,
  `PresentAddress` varchar(100) NOT NULL,
  `About` varchar(300) NOT NULL,
  `HighestEducation` varchar(100) NOT NULL,
  `UGDegreeSubject` varchar(100) NOT NULL,
  `UGDegreeCollege` varchar(100) NOT NULL,
  `PGDegreeSubject` varchar(100) NOT NULL,
  `PGDegreeCollege` varchar(100) NOT NULL,
  `DegreeSubject` varchar(100) NOT NULL,
  `DegreeCollege` varchar(100) NOT NULL,
  `SchoolBoard` varchar(100) NOT NULL,
  `SchoolName` varchar(100) NOT NULL,
  `Occupation` varchar(50) NOT NULL,
  `AnnualIncome` varchar(20) NOT NULL,
  `MotherTounge` varchar(50) NOT NULL,
  `MotherOccupation` varchar(50) NOT NULL,
  `FatherOccupation` varchar(50) NOT NULL,
  `FamilyIncome` varchar(20) NOT NULL,
  `Brother` varchar(20) NOT NULL,
  `Sister` varchar(20) NOT NULL,
  `PermanentAddress` varchar(100) NOT NULL,
  `profilecreationdate` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cust_id` (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (3,3,'Myself','Pooja','Female','Single','05/01/1999','9878456132','Hindu','General: General Caste','Sub-Caste 1','pooja@123.com','A+','Medium Light Brown','20','4ft - 121 cm','50','Vegetarian','No','No','India','Bihar','Patna Bihar','dghfveukfyhgefubhjsgfsd76iwefrehgdsf7i6ryfgufdyuie7udy6w','Inter (Science)','No','No','No','No','No','No','B.S.E.B','Girls High School, ParsaBazaar','Tele Communication','120000','Hindi','Govt. Employee','Farmer','200000','1','1','Patna Bihar','2018-06-01'),(4,13,'Myself','vikash sharan','Male','Single','19/11/89','8521117335','Hindu','General: General Caste','kayatha','vikash.sharan111@gmail.com','B+','Light Pale White','25','5ft 2in - 157cm','56','Vegetarian','Yes','Yes','India','Bihar','gardanibagh','I AM HANDSOME AND POLITE NATURE','mca','computer science','pune university','computer','garware college','java','pune university','cbse','kendriya vidyalaya','private job','7 lakhs','Hindi','house wife','retd. govt job','2 lakhs','2','2','gardanibagh','2018-10-07'),(5,51,'Daughter','Sagarika Chougule','Female','Single','06/04/1993','9423276939','Hindu','General: General Caste','Maratha','jagannathachougule@gmail.com','O+','White Fair','25','5ft 3in - 160cm','-','Vegetarian','No','No','India','Maharashtra','Pune','','Bachelor of Engineering','-','-','-','-','-','-','-','-','-','-','Marathi','House Wife','Retired Govt. Officer','-','1','0','Kolhapur','2018-11-24'),(7,85,'Myself','Vikash Sharan','Male','Single','11/19/1979','7641679762','Hindu','General: General Caste','Brahaman','soft@mail.com','A+','White Fair','27','5ft - 152cm','54','Non-Vegetarian','No','Yes','India','Bihar','Patna','I am happy.','MCA','BCA','kkkk','MCA','kkk','Computer','Pune University','Maharastra','Evening College','Developer','10lac','Hindi','Housewife','Ret.Er','12lac','2','1','Patna','2019-01-29'),(8,93,'Relative','sonu kamble','Male','Single','19/08/1981','9833061410','Buddhist','Buddhist','No','sonuk.2019@rediffmail.com','A+','Black','33','5ft 7in - 170cm','63','Non-Vegetarian','No','No','India','Maharashtra','103 , sai kripa CHS sector9 vashi','I like to play cricket. Listening music','M.Sc','Chemistry','Kirti college','Chemistry','Kirti college','Chemistry','kirti college','Maharashtra state board','vidya mandir','Service','12 lakhs','Marathi','Housewife','Retired','12 lakhs','1','1','same as above','2019-02-11'),(9,136,'Profile For','Vipin Tyagi','Male','Single','06/24/1987','08860283720','Hindu','General: General Caste','Tyagi','viipiintyagi@gmail.com','O+','White Fair','30','5ft 7in - 170cm','64','Sometimes Non-Vegetarian','No','No','India','Uttar Pradesh','Ghaziabad','','Masters','Computers','IMS Roorkee','Computers','IMS Roorkee','Computers','RIT Roorkee','UP','BND ','Salaried','500000','Hindi','House Owner','Farmer','100000','2','1','Muzaffarnagar','2019-04-19');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `Mobile` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (3,'Susan',326573423,'sasoff@bk.ru','You are well aware that most of us have very great opportunities to change ourselves in such a way that our goals become more achievable. \r\n \r\nTo do this, you can go to trainings and get an impulse to move towards your goal. \r\n \r\nBut what to do if there is no financial or other opportunity to participate in trainings? \r\n \r\nIs it possible to change yourself to become more efficient? \r\n \r\nIn addition, the coach may simply not give the changes that you need. \r\n \r\nFor example, your work is related to sales, but you do not get pleasure from sales. You know everything about sales, but you have no enthusiasm to engage in this activity. Therefore, you sell worse than your colleagues, who sell and enjoy the process. \r\n \r\nCan you love the sales process? After all, no one training you do not give such changes. \r\n \r\nIt turns out that such technology of internal changes and discoveries in the qualities you need is available. It is called Technology Self-Transformation of the Person. \r\n \r\nRead about this unique technology in the book Start Your Life Again. 4 steps to a new reality \"on the site https://sviyash.org/ \r\n \r\nThe author of the technology has devoted more than 20 years to the research of those internal barriers that prevent us from being effective on the way to our goals. And determined the most correct sequence of independent actions that will allow us to achieve our goals. \r\n \r\nNo consultants, no trainers, you work on yourself independently. Try it and make sure it works.','2019-04-10 05:09:12'),(4,'Eduardoneese',374275834,'svetlanacol0sova@yandex.ua','Hi jeevansathiindia.com \r\nGrow your bitcoins by 10% per 2 days. \r\nProfit comes to your btc wallet automatically. \r\n \r\nTry  http://bm-syst.xyz \r\nit takes 2 minutes only and let your btc works for you! \r\n \r\nGuaranteed by the blockchain technology!','2019-04-25 09:54:08'),(5,'Stephan',307567586,'rosie.fraser47@msn.com','Hochwertige Waren vom Produzent. Fabrikverkauf.\r\nVersand am gleichen Tag aus Frankfurt. Bis 90 % gÃ¼nstiger als auf dem Markt.\r\n\r\nReifentÃ¼ten mit und ohne Logo.\r\nStretch Folie. Alle GrÃ¶ÃŸen / Sorten.\r\nKartons.\r\nKlebebÃ¤nder.\r\nMalerkrepp. Malerfolie. Werkzeug.\r\nSpÃ¤nesÃ¤cke.\r\n\r\nAlles fÃ¼r Umreifung. Umreifungsband, Verpackungsband, Klemmen, HÃ¼lsen, Spannerâ€¦â€¦.\r\n\r\nGewebesÃ¤cke. KartoffelsÃ¤cke. LaubsÃ¤cke.\r\nRaschelsÃ¤cke. ZwiebelsÃ¤cke.\r\nLuftpolsterfolie.\r\nBaufolie. Estrichfolie. Gartenfolie. Teichfolie. Abdeckfolie. Schutzfolie.\r\nPanzerband. Doppelklebeband. Teppichband.\r\nHandschuhe.\r\nMÃ¼llsÃ¤cke und Vieles mehr.\r\n\r\nInfo auf: folmax.pw\r\n\r\nMit freundlichen GrÃ¼ÃŸen\r\n','2019-05-01 13:06:49'),(6,'DavidBob',238285835,'gunrussia@scryptmail.com','25 charging traumatic pistols shooting automatic fire! Modified Makarov pistols with a silencer! Combat Glock 17 original or with a silencer! And many other types of firearms without a license, without documents, without problems! \r\nDetailed video reviews of our products you can see on our website. \r\nhttp://Gunrussia.pw \r\nIf the site is unavailable or blocked, email us at - Gunrussia@secmail.pro   or  Gunrussia@elude.in \r\nAnd we will send you the address of the backup site!','2019-05-05 06:42:36'),(7,'JosephInset',315168812,'feedbackformeu@gmail.com','While on your great website I felt that my outstanding offer could be a good fit for you. \r\n \r\nIâ€™m happy to say that Iâ€™ve come up with a way for you to get your feet wet in \r\nforex without investing 10k or more right away. 3000â‚¬ will do it here. \r\n \r\nEver seen such proven profits on MyFxBook? Youâ€™ve got to see them with your own eyes. Just go through the links below â€“ opt-in and download a detailed presentation-pdf. \r\n \r\nhttps://www.myfxbook.com/members/OutlierFX/outlierfx/3241807/bMTxDMF2g6KnEToQSQba \r\nhttps://www.outlierfx.com \r\nPlease opt-in to get all info.','2019-05-10 16:00:22'),(8,'ShaneChite',355358575,'michaelLicle@gmail.com','  Look what we get an eye to you! an foremostoffer \r\n To moderate click on the tie-in downstairs  \r\n \r\nhttps://drive.google.com/file/d/1R0aL_ZXzHMNk7OTt6uJAdh6xcMb22F1E/preview','2019-05-16 19:04:20'),(9,'RobertGique',313277542,'di289281@gmail.com','Dear Sir, \r\n \r\nI need your co-operation for a business Partnership. \r\nThis Partnership will give us Hundreds of Millions of Dollars as profit. \r\nKindly write to my personal email address below  so that we can agree on terms and conditions.. \r\nMy Email: h66701824@gmail.com \r\n \r\nSincerely yours, \r\nAndrei Ivanovich Lumpov, \r\nPresident of the expert consulting center ECC. \r\n\"Invest-Project\" Ltd. (Moscow). \r\nEmail: h66701824@gmail.com','2019-05-29 17:38:30'),(10,'Jamesgex',286151251,'intermstores@gmail.com','Dear Sir, \r\nI bring to your notice this multi million business supply that will benefit you and me. \r\nMy company wants to purchase some raw material from your country urgently. \r\nThis raw material is the major material our company uses in production and for research purposes since 2005 and my boss wants to visit your country to source for this raw material but due to my interest in this business, I have contacted you to stand-in as the supplier to supply this raw material to my boss so that we can share the profit.Get back to me immediately for more details about this business supply on my private email:  intermstores9@gmail.com \r\nSincerely, \r\nJere Haas','2019-06-03 20:53:12'),(11,'jeevansathiindia.com',278475736,'micgyhaelLicle@gmail.com','jeevansathiindia.com   Look what we possess due to the fact that you! an interestingdonation \r\n Well-founded click \r\nhttps://drive.google.com/file/d/1LnyHTz41dEBeFvRuQ3Zx2oi1nMgewuY4/preview','2019-06-04 16:12:31'),(12,'jeevansathiindia.com',254611127,'micgyhaelLicle@gmail.com','There is an interesting  bonus for your team. jeevansathiindia.com \r\nhttp://bit.ly/2KAMm5w','2019-06-13 15:58:10'),(13,'ContactForm',375627528,'raphaeclearmrete@gmail.com','Ciao!  jeevansathiindia.com \r\n \r\nWe make offer for you \r\n \r\nSending your business proposition through the feedback form which can be found on the sites in the Communication partition. Contact form are filled in by our application and the captcha is solved. The advantage of this method is that messages sent through feedback forms are whitelisted. This technique raise the chances that your message will be open. \r\n \r\nOur database contains more than 25 million sites around the world to which we can send your message. \r\n \r\nThe cost of one million messages 49 USD \r\n \r\nFREE TEST mailing of 50,000 messages to any country of your choice. \r\n \r\n \r\nThis message is automatically generated to use our contacts for communication. \r\n \r\n \r\n \r\nContact us. \r\nTelegram - @FeedbackFormEU \r\nSkype  FeedbackForm2019 \r\nEmail - FeedbackForm@make-success.com \r\nWhatsApp - +44 7598 509161','2019-06-15 05:35:19'),(14,'WilliamVeilk',222121488,'kelly.cruz@evrosis.com','EVROSIS Technologiesâ€™s turnkey solutions: we customize our products and services to meet the exact requirements of our clients. At EVROSIS TECHNOLOGIES, our developers, engineers, and data scientists are experts in Financial Engineering, High Frequency Trading, Trading Platform & financial markets. \r\n \r\nOur competitive strengths: High Speed Networks Development, High Performance Computing, Deep Learning A.I., High Sharpe Ratio Trading models, and talented Quant Traders. \r\n \r\nYou can Get custom Trading Solutions for any Exchanges/ECNs in The World or use pre-prepared Solutions and Profit from a state-of-the-Art Model. You will save Time and Money by Working with Us. \r\n \r\nContact us and we will implement your needs. \r\n \r\nKind regards \r\n \r\n \r\nWebsite : http://bit.ly/2ZysS5z \r\nSkype: support.evrosis \r\nE-mail : info@evrosis.com \r\nEVROSIS Technologies Ltd. \r\n130 Old Street, London, United Kingdom, EC1V 9BD','2019-06-23 05:05:27'),(15,'jeevansathiindia.com',254611127,'micgyhaelLicle@gmail.com','Look at an important  prize for victory. jeevansathiindia.com \r\nhttp://bit.ly/2KEtsL7','2019-06-24 10:43:50'),(16,'OuidaHat',234725483,'fax.promotion@consultant.com','Are you an individual businessman or a business organization that wants to expand in business but has problem with funding? \r\nIntermediaries/Consultants/Brokers are welcome to bring their clients and are 100% protected. In complete confidence, we will work together for the benefits of all parties involved. \r\nContact us on this email: razulizabiti@consultant.com \r\nRegards, \r\nRazul Izabiti','2019-06-25 00:03:03'),(17,'RichardWes',264268455,'gulfsrv94@gmail.com','Good day!, jeevansathiindia.com \r\n \r\nOur patron want to fund in your district for good gain. \r\n \r\nPlease contact us for more information on  +973 650 09688 or mh@indobsc.com \r\n \r\nBest regards \r\nMr. Mat Hernandez','2019-06-25 11:27:38'),(18,'Eyewoowl',81629898358,'ginaj@probbox.com ','[url=https://cafergot1.com/]cafergot medication[/url] ','2019-07-30 03:43:38'),(19,'Eyewoowl',85639688698,'fdominguez@probbox.com ','[url=https://cafergot1.com/]cafergot & internet pharmacy[/url] ','2019-07-30 03:45:45'),(20,'Eyewoowl',81282435273,'lailacavalcanti@probbox.com ','[url=https://cafergot1.com/]cafergot[/url] ','2019-07-31 15:02:01'),(21,'Eyewoowl',84371611491,'meredith@probbox.com ','[url=https://cafergot1.com/]cafergot[/url] ','2019-08-02 01:34:46'),(22,'Eyewoowl',84772432938,'rconnelly980@probbox.com ','[url=https://cafergot1.com/]cheap cafergot[/url] ','2019-08-03 12:55:16'),(23,'Eyewoowl',82213335566,'carry@probbox.com ','[url=https://cafergot1.com/]cafergot tablets[/url] ','2019-08-04 23:55:42'),(24,'jeevansathiindia.com',83135579542,'micgyhaelLicle@gmail.com','Like note actual  offers because victory. jeevansathiindia.com \r\nhttp://bit.ly/2NN0HyZ','2019-08-05 03:42:27'),(25,'Eyewoowl',81533239964,'cml1031@probbox.com ','[url=https://cafergot1.com/]generic cafergot[/url] ','2019-08-06 11:16:03'),(26,'Eyewoowl',83554983482,'bianca@probbox.com ','[url=https://cafergot1.com/]cafergot[/url] ','2019-08-07 19:36:38'),(27,'Eyewoowl',89179914358,'nikulas01cv@probbox.com ','[url=https://cafergot1.com/]generic cafergot[/url] ','2019-08-09 06:30:51'),(28,'VurneVob',87641571648,'elosbnfea@qmails.co','Buy tadalafil india cipla <a href=\"http://cialisndbrx.com/#\">buy cialis online</a> generic cialis free shipping <a href=\"http://cialischmrx.com/#\">buy cheap cialis online</a> wiki generic viagra cialis pills <a href=\"http://cialischbrx.com/#\">buy generic cialis online</a> generic cialis vs cialis order <a href=\"http://cialisdbrx.com/#\">buy cheap cialis online</a> chinese herbal viagra <a href=\"http://chviagranrxusa.com/#\">buy generic viagra online</a>','2019-08-12 13:41:11'),(29,'DavidTwego',82613314689,'raphaeclearmrete@gmail.com','Ciao!  jeevansathiindia.com \r\n \r\nWe offer \r\n \r\nSending your message through the Contact us form which can be found on the sites in the Communication section. Feedback forms are filled in by our software and the captcha is solved. The profit of this method is that messages sent through feedback forms are whitelisted. This method raise the odds that your message will be open. \r\n \r\nOur database contains more than 25 million sites around the world to which we can send your message. \r\n \r\nThe cost of one million messages 49 USD \r\n \r\nFREE TEST mailing of 50,000 messages to any country of your choice. \r\n \r\n \r\nThis message is automatically generated to use our contacts for communication. \r\n \r\n \r\n \r\nContact us. \r\nTelegram - @FeedbackFormEU \r\nSkype  FeedbackForm2019 \r\nEmail - FeedbackForm@make-success.com','2019-08-13 05:21:34'),(30,'WilliamLoony',81271863454,'earry1960@superrito.com','That is an urgentoffers recompense you. http://alryoumatemp.tk/ib3tm','2019-08-19 05:26:14'),(31,'Scoova',86788876947,'lgaerfkls0@qmails.pro','Viagra floaters cialis pills cialis <a href=\"http://www.cialisongen.com/#\">buy generic cialis</a> viagra pills canada cialis 20mg buy <a href=\"https://cialisnorxs.com/#\">cheap cialis</a> payday loans oklahoma city <a href=\"http://paydaysonlinemoney.com/#\">quick cash</a>','2019-08-27 00:48:14'),(32,'Uncessy',84268839667,'lgaerfkls0@qmails.co','<a href=\"http://cashpaydayusloans.com/#\">same day loans</a> <a href=\"http://viagrabstnrx.com/#\">cheap viagra online</a> <a href=\"http://cialisherrx.com/#\">buy cialis</a> <a href=\"http://cialisknfrx.com/#\">buy cheap cialis online</a> <a href=\"http://cialisdbrx.com/#\">cheap generic cialis</a> ','2019-08-27 21:02:03'),(33,'kahslaby',83653357348,'lgaerfkls2@qmails.co','<a href=\"http://paydaymycreditloan.com/#\">payday loans online</a> <a href=\"http://calismdmrxonline.com/#\">buy cialis</a> <a href=\"http://cashpaydayusloans.com/#\">quick cash advance online</a> <a href=\"http://viagrabstnrx.com/#\">cheap viagra online</a> <a href=\"http://genviagramdmrx.com/#\">viagra</a> ','2019-08-27 21:02:03'),(34,'swerova',81933684273,'lgaerfkls1@qmails.co','<a href=\"http://cialisdbrx.com/#\">generic cialis online</a> <a href=\"http://genviagramdmrx.com/#\">viagra online</a> <a href=\"http://viagralx.com/#\">generic viagra</a> <a href=\"http://cialiishb.com/#\">cialis generic</a> <a href=\"http://cashpaydayusloans.com/#\">loans bad credit</a> ','2019-08-27 21:02:03'),(35,'idedia',83349829333,'lgaerfkls0@qmails.pro','Viagra rap buy cialis online <a href=\"http://www.cialisongen.com/#\">buy generic cialis</a> cialis canada online <a href=\"https://cialisnorxs.com/#\">cheap cialis</a> bad credit lenders only <a href=\"http://paydaysonlinemoney.com/#\">payday loans online</a>','2019-08-27 22:15:31'),(36,'Incoge',86951986853,'lgaerfkls2@qmails.pro','Emedicine viagra cialis pills <a href=\"http://www.cialisongen.com/#\">buy generic cialis</a> cialis generic sicuro <a href=\"https://cialisnorxs.com/#\">generic cialis online</a> how can i get a personal loan with bad credit <a href=\"http://paydaysonlinemoney.com/#\">pay day loans</a>','2019-08-27 22:34:07'),(37,'bogyToma',83367793476,'lgaerfkls1@qmails.pro','Cialis <a href=\"http://www.cialisongen.com/#\">buy generic cialis online</a> buy cheap generic cialis online cialis <a href=\"https://cialisnorxs.com/#\">generic cialis online</a> cash advances for bad credit <a href=\"http://paydaysonlinemoney.com/#\">quick cash</a>','2019-08-27 22:34:08');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partnerprefs`
--

DROP TABLE IF EXISTS `partnerprefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partnerprefs` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `cust_id` int(10) NOT NULL,
  `AgeTo` varchar(10) NOT NULL,
  `AgeFrom` varchar(10) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `HeightTo` varchar(30) NOT NULL,
  `HeightFrom` varchar(30) NOT NULL,
  `MaritalStatus` varchar(20) NOT NULL,
  `Religion` varchar(50) NOT NULL,
  `Caste` varchar(50) NOT NULL,
  `SubCaste` varchar(50) NOT NULL,
  `Education` varchar(50) NOT NULL,
  `Occupation` varchar(50) NOT NULL,
  `MotherTounge` varchar(50) NOT NULL,
  `Country` varchar(100) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Income` varchar(30) NOT NULL,
  `About` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partnerprefs`
--

LOCK TABLES `partnerprefs` WRITE;
/*!40000 ALTER TABLE `partnerprefs` DISABLE KEYS */;
INSERT INTO `partnerprefs` VALUES (1,1,'18','24','Female','150','170','Single','Muslim','BC: Backward Category','Sub-Caste 1','Degree','Web Developer','Hindi','India','Bihar','120000','fgdfiaeyrgffhjbvfkdyfgesaydusahgdkvbsfjhnfgyekjkf87fhfi76awFKYfEF');
/*!40000 ALTER TABLE `partnerprefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `photos`
--

DROP TABLE IF EXISTS `photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` int(10) NOT NULL,
  `pic` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cust_id` (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photos`
--

LOCK TABLES `photos` WRITE;
/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
INSERT INTO `photos` VALUES (1,1,'Desert.jpg'),(2,4,'Lighthouse.jpg'),(3,3,'Lighthouse.jpg');
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `profilestat` int(2) NOT NULL,
  `ProfileFor` varchar(20) NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `DateOfBirth` varchar(20) NOT NULL,
  `Religion` varchar(20) NOT NULL,
  `MobileNo` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `userlevel` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (6,0,'Myself','Vikku kumar','Male','14/08/1997','Hindu','7903930684','vishalkr1481997@gmail.com','Vishalkr1481997@gmail.com','vishalkr',0),(7,0,'Relative','Dr. Yash Raj Anand','Male','15/07/1985','Hindu','8505966098','mahendra.k190455@gmail.com','yranand','april1955',0),(8,0,'Brother','Avinash Kumar','Male','08/30/1989','Hindu','9650845753','Kumaravinash.1989830@gmail.com','Kumaravinash.1989830@gmail.com','Avinash108',0),(10,0,'Myself','A. P. Ch.','Male','1990/01/15','Hindu','9851157446','chaulagainarjun@ymail.com','A.p.chaulagain','apc03783',0),(11,0,'Myself','Basavaraj Karbhosaga','Male','18/01/1981','Hindu','9900682100','bskarbhosaga@yahoo.com','bskarbhosaga','eagle@012',0),(12,0,'Myself','Basavaraj Karbhosaga','Male','18/01/1981','Hindu','9900682100','bskarbhosaga@rediffmail.com','bskarbhosaga@rediffmail.com','eagle@012',0),(25,0,'Myself','Ashish kumar jha','Female','03/03/1990','Hindu','8368257686','ashishkumarjha1001@gmail.com','Ashish','64358866a',0),(37,0,'Myself','OMPRAKASH ','Male','02/06/1995','Hindu','9829347543','omgodara9829@gmail.com','omprakash ','à¤“à¤®à¥à¤ªà¥à¤°à¤•à¤¶9829',0),(42,0,'Friend','Umesh','Male','15.08.1996','Hindu','8448012710','umeshkr468@gmail.com','Umesh','8448012710',0),(43,0,'Myself','Sunita nalavade','Female','09/06/1989','Hindu','7796597944','sunitanalavade11@gmail.com','Sunita nalavade','sunita11#,',0),(51,0,'Daughter','Sagarika Chougule','Female','06/04/1993','Hindu','9423276939','jagannathachougule@gmail.com','sagarika.c','S@garika1',0),(55,0,'Myself','Alexandre Bella','Female','01/09/2006','Christian','2133406251','gramsmaris@gmail.com',' Bella','adenike23',0),(59,0,'Myself','Tushar Saxena','Male','07/26/1990','Hindu','8779571239','vision.beyond87@gmail.com','TuShAr SaXeNa','tushar@786',0),(60,0,'Myself','bhupendra yadav','Female','2/08/2013','No Religious Belief','9876843211','dipankarjee6@gmail.com','1','1',0),(65,0,'Myself','Sonu kumar','Male','28/12/1994','Hindu','8521210825','sonukumar281294@gmail.com','Sonukrchy','8757508152',0),(66,0,'Myself','Komal','Female','03/03/1997','Hindu','9922185760','komallate193@gmail.com','komal123','komal',0),(67,0,'Myself','Rekha wadhwa','Female','31/12/1979','Hindu','9034548570','rekhawadhwa2015@gmail.com','Rekha1979','m9991345139',0),(68,0,'Relative','RAKESH GUPTA','Male','11/09/1967','Hindu','8587886992','pnsharma3919@gmail.com','rakesh','091166rkg',0),(69,0,'Myself','Mdsaddamhossain','Male','07 03 1991','Muslim','8759234786','mdsaddamhossain908@gmail.com','Md saddam hossain','8759234786',0),(70,0,'Myself','Anand vishwakarma','Male','27/02/1999','Hindu','8700665930','av966907@gmail.com','Anand vish','anand1478',0),(72,0,'Myself','Tofa yadav ','Female','2/08/2013','Hindu','9848177775','tofayadav@yahoo.com','Tofa yadav ','9848177775',0),(73,0,'Sister','ABHISHEK RAJ','Male','01/23/2019','Hindu','07549393999','abhishekmonty007@gmail.com','Abhishek Raj','7549393999',0),(81,0,'Myself','Aayad Khan','Male','01/01/1975','Muslim','9999008718','aayadkhan7@gmail.com','khan','nasreen248',0),(83,0,'Friend','samir','Male','01/01/1998','Muslim','8630583415','samirkhan59074@gmali.com','samir','sadd0786',0),(86,0,'Myself','Prabhakar Kumar','Male','28/01/1994','Hindu','8709629385','samirjha05@gmail.com','samirjha05','prabhakar123.',0),(87,0,'Myself','Subir chakraborti','Male','01/05/1996','Hindu','01316609613','subirchakraborti95471@gmail.com','Subir Chakraborti ','subir420',0),(91,0,'Daughter','lukannadeexego','','mm/dd/yyyy','Hindu','','wi.shannon80@gmail.com','lukannadeexego','3&4sue5ejJL',0),(92,0,'Friend','R k gupta','Male','02/10/1995','Hindu','8566909882','gorepandey103@gmail.com','G p','gaurav12',0),(93,0,'Relative','sonu kamble','Male','19/8/1981','Buddhist','9833061410','sonuk.2019@rediffmail.com','rajesh kamble','biranwadi1',0),(95,0,'Myself','SAURABH KANT','Male','09/10/1990','Hindu','9760939202','saurabh.kant4@gmail.com','saurabh kant','9557074434',0),(96,0,'Friend','Millard','Male','21101990','No Religious Belief','7435832171','frankysommy5@gmail.com','MillardH','testimonytime0991',0),(97,0,'Myself','Shahid Hassan','Male','16/02/1984','Muslim','9973131248','shahid_hassan1979@yahoo.co.in','Jsindia5@gmail.com','danish@786D',0),(98,0,'Friend','adnan','Male','1994','Muslim','91822206','suraja910@gmail.com','adnan','aasialovea',0),(99,0,'Relative','PINTU','','2/08/2013','Hindu','9058513887','pksinghp800@gmail.com','PINTU','80066850',0),(101,0,'Myself','Sonu Manku','Male','12/10/2000','Sikh','8284942358','Www.Sonu Manku.Js.Com','Sonu Manku','123456789101112',0),(102,0,'Myself','Pankaj Jalindar salunke ','Male','1/12/1999','Hindu','9284139700','Pankajsalunke097@gmail.com','Pankaj ','pankaj',0),(109,0,'Myself','shivika','Male','10/18/1983','Hindu','9811560620','shivika.attray@gmail.com','Shivika Attray ','khushi123',0),(124,0,'','Esme Hale','Female','mm/dd/yyyy','','Esme Hale','persedia2022@gmail.com','Esme Hale','Esme Hale',0),(125,0,'','Alicia Wu','Female','mm/dd/yyyy','','Alicia Wu','persedia2024@gmail.com','Alicia Wu','Alicia Wu',0),(126,0,'Daughter','Bremarnadeexego','','mm/dd/yyyy','Parsi','','vaclav_kuba.634@yahoo.com','Bremarnadeexego','3&4sue5ejJL',0),(127,0,'Son','arun','Male','06/01/1983','Hindu','(967) 091-6673','ashishsbr11@gmail.com','asihshsbr11@gmail.com','ashishS87',0),(128,0,'','','','','','','','','',0),(130,0,'Brother','ktrcfifnadeexego','','mm/dd/yyyy','Jewish','','christian_john_205@yahoo.com','ktrcfifnadeexego','3&4sue5ejJL',0),(136,0,'Myself','Vipin Tyagi','Male','06/24/1987','Hindu','08860283720','viipiintyagi@gmail.com','VipinTyagi','C#@98089997',0),(140,0,'Brother','Ashish Tiwari','Male','02/01/1991','Hindu','9867166234','heaven122@rediffmail.com','Ashish','mahakal456',0),(143,0,'Brother','Ashish Tiwari','Male','02/01/1991','Hindu','9867166234','manojrocks1010@gmail.com','Ashish','mahakal456',0),(149,0,'Brother','cntgfyblrfnadeexego','','mm/dd/yyyy','Christian','','jazrecthebur8035@yahoo.com','cntgfyblrfnadeexego','3&4sue5ejJL',0),(154,0,'Son','Anayamathnadeexego','','mm/dd/yyyy','No Religious Belief','','ocacstabtan8716@yahoo.com','Anayamathnadeexego','3&4sue5ejJL',0),(155,0,'Myself','Sanjay Prasad','Male','10/08/1991','Hindu','9088844980','sanjayprasad91.sp@gmail.com','sanjayprasad91.sp@gmail.com','908884490',0),(156,0,'Friend',' Rajesh','Male','5/8/1982','Hindu','8929235163','rs3881442@gmail.com','rajesh','live12345',0),(157,0,'Sister','Valyushanadeexego','','mm/dd/yyyy','Christian','','trestnano@gmail.com','Valyushanadeexego','3&4sue5ejJL',0),(159,0,'Friend','fanianadeexego','','mm/dd/yyyy','Bahai','','flovertoreto@gmail.com','fanianadeexego','3&4sue5ejJL',0),(160,0,'Daughter','puja verma','Female','05/05/1996','Hindu','8986880057','puja60864@gmail.com','puja verma','puja1234',0),(161,0,'Myself','soif@fuhoy.com','Male','06/24/2019','Bahai','576987689','soif@fuhoy.com','soif@fuhoy.com','soif@fuhoy.com',0),(162,0,'Son','levontiusnadeexego','Male','mm/dd/yyyy','Christian','83821362341','treko9645@gmail.com','levontiusnadeexego','3&4sue5ejJL',0),(163,0,'Myself','TCT','Male','08/26/2019','Sikh','0701234625','bacod@gmail.com','TCT','TCT',0),(164,0,'Friend','fgjkkbyfhbqnadeexego','Male','mm/dd/yyyy','Sikh','81323525531','jdresk@gmail.com','fgjkkbyfhbqnadeexego','3&4sue5ejJL',0),(165,0,'Friend','Topmennadeexego','Male','mm/dd/yyyy','Buddhist','87418758491','loosterf@gmail.com','Topmennadeexego','4&use24HyyJ',0),(166,0,'Myself','Krunal patel','Male','15/05/1994','Hindu','6352389022','krushpatel00@gmail.com','Krunalpatelkr','krunal@patel',0),(167,0,'Myself','Mrinal','Male','03/08/1992','Hindu','7972215112','mbmcom31@gmail.com','Mrinal','mrinal',0),(168,0,'Brother','mr lool','Male','05/08/1999','Hindu','01896325869','mrlool@gmail.com','lool00','lool00',0),(169,0,'Myself','Abyasa Adiratna','Female','12/10/1969','Muslim','708523157','abyasaadiratna01@hotmail.com','moreme','love123456',0),(170,0,'Myself','Shivani jha','Female','15 10 1996','Hindu','9661489808','shivanijha093@gmail.com','Shivani jha ','shivanijha9808',0),(172,0,'Son','MaricelaPluntee','Male','mm/dd/yyyy','Parsi','82286522139','uhnevicdiana987@gmail.com','MaricelaPluntee','1naWe25HyyJ',0),(173,0,'Relative','kfifPluntee','Male','mm/dd/yyyy','Christian','82755251989','putatinvladislav573@gmail.com','kfifPluntee','1naWe25HyyJ',0),(174,0,'Myself','Rakesh Manuj','Male','15/08/1972','Hindu','3232125903','rrr48727@gmail.com','Rakesh Manuj','danson1122',0),(175,0,'','cheyanne frazier','Female','mm/dd/yyyy','','cheyanne frazier','cheyannefrazier.sc.83662620@supersendme.org','cheyanne frazier','cheyanne frazier',0),(176,0,'','cheyanne frazier','Female','mm/dd/yyyy','','cheyanne frazier','cheyannefrazier.sc.83662621@supersendme.org','cheyanne frazier','cheyanne frazier',0),(177,0,'','elsa douglas','Female','mm/dd/yyyy','','elsa douglas','elsadouglas.sc.65705279@digitalfall.ga','elsa douglas','elsa douglas',0),(178,0,'','erin orr','Female','mm/dd/yyyy','','erin orr','erinorr.sc.65705278@digitalfall.ga','erin orr','erin orr',0),(179,0,'Daughter','LeffertPluntee','Male','mm/dd/yyyy','Sikh','83471394468','urijgubin436@gmail.com','LeffertPluntee','1naWe25HyyJ',0),(180,0,'Myself','Caitlin Kingston','Male','11/11/1999','Bahai','(225) 252-6584','bqk93667@bcaoo.com','ddeed','bqk93667@bcaoo.com',0),(182,0,'Relative','Aleksandar','Male','02/06/1976','No Religious Belief','+79036622776','psylos@mail.ru','psylos','ljubljana',0),(183,0,'Myself','suraj kumar','Male','3/13/1995','Hindu','9643217342','abhay123@gmail.com','suraj','suraj',0),(184,0,'','averi green','Female','mm/dd/yyyy','','averi green','averigreen.sc.579744387@supersendme.org','averi green','averi green',0),(185,0,'','averi green','Female','mm/dd/yyyy','','averi green','averigreen.sc.579744388@supersendme.org','averi green','averi green',0),(186,0,'Son','dctdjkjlPluntee','Male','mm/dd/yyyy','Christian','89863122541','torpmeendxg@gmail.com','dctdjkjlPluntee','1naWe25HyyJ',0),(187,0,'Myself','rakesh','Male','01/15/2020','Christian','9865321245','nk316358@gmail.com','vikash','betichode',0),(192,0,'Son','Ajay Sharma','Male','12/11/1995','Hindu','910701724','satyaillichmann@gmail.com','satyapalhari','ajaykumar',0),(193,0,'Myself','virender naryal','Male','05/26/1980','Hindu','9876095754','naryalvirender26@gmail.com','virender','dikshant',0),(194,0,'','zackary page','Female','mm/dd/yyyy','','zackary page','zackarypage.sc.328001377@supersendme.org','zackary page','zackary page',0),(195,0,'','zackary page','Female','mm/dd/yyyy','','zackary page','zackarypage.sc.328001378@supersendme.org','zackary page','zackary page',0),(196,0,'Brother','Shashi Bhushan Kumar','Male','24/08/1990','Hindu','8877663551','bhushan.kumar19@gmail.com','@bhushan123','@manish123',0),(197,0,'Son','fallenPluntee','Male','mm/dd/yyyy','Buddhist','87854964887','mozzh.masha1@gmail.com','fallenPluntee','1naWe25HyyJ',0),(199,0,'Friend','seasPluntee','Male','mm/dd/yyyy','Parsi','85875354686','umantsevamil5@gmail.com','seasPluntee','1naWe25HyyJ',0),(200,0,'Myself','Kapil Sehgal ','Male','28/12/1984','Hindu','9971190861','kapil.sehgal2017@gmail.com','Kapil ','momdad@1',0),(203,0,'Brother','rjhybkrfPluntee','Male','mm/dd/yyyy','Hindu','84412931853','tingaykina.alla@gmail.com','rjhybkrfPluntee','1naWe25HyyJ',0),(208,0,'Sister','dfcbktqPluntee','Male','dd/mm/yyyy','Hindu','82284427112','natashanarysh2@gmail.com','dfcbktqPluntee','1naWe25HyyJ',0),(209,0,'','riya key','Female','dd/mm/yyyy','','riya key','riyakey.gm.117517809@pilosella.club','riya key','mary green',0),(210,0,'','elsa snyder','Female','dd/mm/yyyy','','elsa snyder','elsasnyder.gm.117517810@pilosella.club','elsa snyder','elsa snyder',0),(211,0,'','cheyanne villarreal','Female','dd/mm/yyyy','','cheyanne villarreal','cheyannevillarreal.sc.495354533@mojorage.life','cheyanne villarreal','cheyanne villarreal',0),(212,0,'','cheyanne villarreal','Female','dd/mm/yyyy','','cheyanne villarreal','cheyannevillarreal.sc.495354532@mojorage.life','cheyanne villarreal','cheyanne villarreal',0),(213,0,'Relative','avdokimPluntee','Male','dd/mm/yyyy','Jewish','82761421327','galyakor4@gmail.com','avdokimPluntee','1naWe25HyyJ',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'jeevansathindia'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-09  7:20:07
