-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: localhost    Database: sacadmin
-- ------------------------------------------------------
-- Server version	5.6.49-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `sacadmin`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sacadmin` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sacadmin`;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin@sac','Vk@191179');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backupdata`
--

DROP TABLE IF EXISTS `backupdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backupdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backupdata`
--

LOCK TABLES `backupdata` WRITE;
/*!40000 ALTER TABLE `backupdata` DISABLE KEYS */;
INSERT INTO `backupdata` VALUES (1,'Excel sheet 2018(keshab) ','backupfile/1553923589workbook.xlsx','2019-03-30 10:56:29'),(2,'Excel sheet 2018','backupfile/1553923973workbook.xlsx','2019-03-30 11:02:54'),(3,'clients 2018 excel sheet(pooja mam)','backupfile/1553944712Copy of Copy of Annual_Report_2018-2019 - Copy.xlsx','2019-03-30 16:48:32'),(4,'Cok','backupfile/1602470448cok(2).html','2020-10-11 19:40:48');
/*!40000 ALTER TABLE `backupdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `video` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `posted` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `career`
--

DROP TABLE IF EXISTS `career`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `career` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `resume` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `career`
--

LOCK TABLES `career` WRITE;
/*!40000 ALTER TABLE `career` DISABLE KEYS */;
INSERT INTO `career` VALUES (1,'puja','PHP','B.Tech','Patna',9087654321,'resume/1561460412index.php','2019-06-25 04:00:12'),(2,'Suraj Kumar','php','mca','patna',8859572225,'resume/1585986202radhe ITI_logo0.png','2020-04-04 00:43:22'),(3,'Suraj Kumar','php','mca','patna',8859572225,'resume/1585986229radhe ITI_logo0.png','2020-04-04 00:43:49');
/*!40000 ALTER TABLE `career` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientvisit`
--

DROP TABLE IF EXISTS `clientvisit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientvisit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` varchar(255) NOT NULL,
  `contactperson` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `landmark` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `projecttype` varchar(255) NOT NULL,
  `status` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client` (`client`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientvisit`
--

LOCK TABLES `clientvisit` WRITE;
/*!40000 ALTER TABLE `clientvisit` DISABLE KEYS */;
INSERT INTO `clientvisit` VALUES (1,'Koi Hain','Hum hain','Patna, 800001','patna gardanibaag','patna',9876543290,'coaching','ok yess','2019-03-28 13:59:32'),(2,'panchwati inn guest house','shreekant ','ias colony,bailey road,service lane saguna more,rupaspur nahar andexced bajaj showroom','atlantis super specialty hospital','patna',9006458321,'guest house','project final started','2019-03-28 14:17:05'),(3,'arrya dance academi','amit arrya','bazitpur, lal kothi, barh','staion road','patna',8084678004,'dance class','interested','2019-03-28 15:15:58'),(4,'Sagar sound and deoration','Abhinsh kumar','gulani ,devi mandir, petrol tanki','railway crossing','Hilsa',9534662631,'tent house','interested','2019-04-15 22:59:43'),(5,'apex nateraj dance  academy','sumit sharma','sri hari arcade, jahaji khoti  road, kadamkuan','area appartment','patna',8936869151,'dance class','interested','2019-03-28 15:27:29'),(6,'AIPA dance academy','anupam kumar ','bailey road jagdeopath, haldiram ','pillar no-11, jant hotel','patna',8581008007,'dance class','interested','2019-03-28 15:30:59'),(7,'Thakurs english','Manoj kumar','2and floor,khushi market,musallahpur hat,rampura lane mahendru','shahid jagdeo','patna',9152586772,'coaching','interested','2019-03-28 15:36:56'),(8,'shivam property and developers','s.n jha','shop no 1,shakti commercial complex,boring road, patna ','beside allankar place','patna',9334163587,'real estate','interested','2019-03-28 15:44:11'),(9,'sandhaya caterer','praveen  kumar','G/107, budha buiding ,p.c. colony,kankerbagh','hanuman mandir','patna',9334346354,'caterer','interested','2019-03-28 15:50:10'),(10,'dance and fitness studio','j d','judges colony,kaliket nagar  , danapur','kaliket nagar','patna',9308476978,'dance class','interested','2019-03-28 15:54:53'),(11,'ratan shobha motor training school','Vivek kumar','ashok raj path, gulzarbagh','alamgani','patna',9386175020,'training school','interested','2019-03-28 16:00:41'),(12,'radhika marble and tiles','Anil kumar','godavari palace, saguna more','royal enfield showroom','patna',8102976891,'marble','interested','2019-03-28 16:09:37'),(13,'vishal catering service','Ajay patel','bldng no 3,road no 21, rajeev nagar ','atta chakki meal','patna',9334556355,'caterer','interested','2019-03-28 16:19:31'),(14,'kumar motor trainig school','baiju kumar','j-12,pc colony,kankarbagh, back side of rps school,patna','rps school','patna',930458637,'training school','interested','2019-03-28 16:34:56'),(15,'priti rest house','Sanjay kumar','kankarbagh main road','woodland showroom','patna',9386888510,'guest house','interested','2019-03-28 16:38:23'),(16,'om sai tour and travel','balmiki gupat','magadh colony kurji road, hd fc bank','loyola school','patna',9334053972,'travel','interested','2019-03-28 16:48:41'),(17,'pankhuri pariwar  ca hostel','Anil kumar','vijay nagar rukampura patliputra station road','station road','patna',9835208305,'hostel','interested','2019-03-28 16:56:25'),(18,'Kanishka enterprises','niranjan kumar','minta market, patna ,new bypass,new jaganpura ,mangal chowk, khemnichak','khemnichak','patna',9152721204,'marble','interested','2019-03-28 17:04:34'),(19,'gurukul shiksha kendra','a.k sir','panchwati bhawan bhikhana pahari ','polic station','patna',9470020696,'coaching','interested','2019-03-28 17:13:07'),(20,'pal restaurents','Niraj kumar','om vihar, 1st floor, dak banglaw road kadamkuan','dak banglaw road','patna',9334118238,'restaurant','interestde','2019-03-28 17:19:50'),(21,'NAC classes','Abneesh kumar singh','Laxmi Market (Near Chitkohra Masjid) , Chitkohra, Anisabad, Patna - 800002, Bihar','above axis atm','Patna',9507571859,'coaching','Final','2019-03-29 11:22:35'),(22,'gyan sagar public school','madhursurendr kr','gola road ,danapur bazar, behind ram janki mandir','ram  janki  mandir','patna',9608220229,'software','final','2019-03-29 12:16:50'),(23,'maa sharde boys ','kundan','house no 11 ,boring road','jamuna apartment','patna',9122165576,'hostel','interested','2019-03-29 16:41:38'),(24,'deep raj tiles','Rajiv kumar','nayatola, kankarbagh main road ,kumhrar','kumhrar park','patna',9152645778,'marble','interested','2019-03-29 16:45:43'),(25,'H P pvt i.t.i','bikarant kumar','road no 9, rajeev nagar,keshri nagar,svm residential public school','svm residential public school','patna',9934002546,'institute','interested','2019-03-29 16:50:16'),(27,'magadh marble','aman kumar ','brahmsthn ,','machli market','patna',9504488255,'marble','interested','2019-03-29 17:17:47'),(28,'delhi central school','Manoj kumar','chandi','chandi','Hilsa',8540037996,'school','interested','2019-04-15 23:04:05'),(29,'Tulsiyan enterprises','anil kumar','marai road, hajipura ','dav school','hajipur',9507374409,'marble','final','2019-03-29 17:22:22'),(30,'om sai guest house ','rahul kumar','krishna apartment, children park','children park','patna',9931663662,'guest house','interested','2019-03-29 17:24:33'),(31,'jay medico','j p sharma','SADAR HOSPITAL VAISHALI','SADAR HOSPITAL','patna',7488096059,'medical','interested','2019-03-29 17:27:21'),(32,'gyan niketan gurukul kids world','mudhurendr','gola road danapur bazar, behind ram janki mandir','ram  janki  mandir','patna',9608220229,'school','final','2019-03-29 17:39:20'),(33,'cosmic international','sanjay jha','hotel kumar building jamal road','behind bank of india','patna',8210758459,'institute','interested','2019-03-30 11:51:28'),(34,'poonam medico','vijay','aanand bazar,danapur bazar','ghandi murti','patna',9334058905,'medical','interested','2019-03-30 11:55:36'),(35,'vivekanand girls hostel','pankaj kumar','house no 4, vivekanand marg, boring road','axis bank','patna',7543030360,'hastel','interested','2019-03-30 12:09:19'),(36,'raj agencies','charanjit singh','mahabeera apartment jahaji kothi, kadamkuan','jahaji kothi','patna',9835654198,'caterer','interested','2019-03-30 12:18:40'),(37,'sonu medical hall','vikash kumar','chail chowk , hajipur ','blue bells school','hajipur',9631014920,'medical','interested','2019-03-30 12:22:14'),(38,'ashirwad marriage hall','Rakesh kumar','heganpura','kst callege','nalanda',8987390434,'marriage hall','interested','2019-03-30 12:29:51'),(39,'Om shree sai ram travels','abhayanand ji ','biharshrif','kalika chowk','nalanda',9798342958,'travel','interested','2019-03-30 12:37:30'),(40,'B.K. institute','Jashwant kumar','ashiana digha road, ashiana nagar','ashiana nagar','patna',9572132411,'coaching','inaterested','2019-03-30 12:42:42'),(41,'rahmans 30','rahman','T-1, Sundus Complex \r\nOpp. Patna University \r\nAshok Rajpath','patna university','patna',9122391223,'institute','final','2019-03-30 12:47:31'),(42,'paramount coaching center pvt ltd','veeneet','1st Floor, Vidan, Bari Path, Nayatola,ya Bhaw, Near Sai Mandir, Patna - 800004','sai mandir','patna',7033097666,'coaching','interested','2019-03-30 12:57:10'),(43,'singh ambulance','bajarangi','G 73, pc colony, kankarbagh','manju  sinha park','patna',9386802092,'ambulance','not interested','2019-03-30 13:32:11'),(44,'xxxxx','xxx','patna','patna','patna',9876543210,'Institute','yess','2019-04-02 05:22:02');
/*!40000 ALTER TABLE `clientvisit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientworksheet`
--

DROP TABLE IF EXISTS `clientworksheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientworksheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` varchar(255) NOT NULL,
  `contact` bigint(10) NOT NULL,
  `contactperson` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `projecttype` varchar(255) NOT NULL,
  `typeofwork` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `lastcall` varchar(255) NOT NULL,
  `recall` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `moveto` varchar(100) NOT NULL,
  `meetingdate` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client` (`client`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientworksheet`
--

LOCK TABLES `clientworksheet` WRITE;
/*!40000 ALTER TABLE `clientworksheet` DISABLE KEYS */;
INSERT INTO `clientworksheet` VALUES (1,'NAC',9507571859,'Abneesh Kumar','Patna','Institute','Website','Laxmi Market (Near Chitkohra Masjid) , Chitkohra, Anisabad, Patna - 800002, Bihar','01/12/2018','07/12/2018','fixed','Fixed','19/03/2019','2019-03-29 11:31:09'),(2,'The Inspire',9876543210,'M Karimi','Gaya','Institute','Website','Opposite Bombay Sales, SILKY COTTAGE,\r\nG.B.Road, Gaya\r\n','2018-07-03','2019-03-27','interested','Fixed','','2019-03-29 11:30:22'),(3,'Om property  services',9334122306,'Binod kumar','patna','real estate','website','Rai Construction, Gorakhnath Lane, Boring Road, Patna - 800001, Behind Harihar ChamberÂ \r\n','2019-jul-16','2019-aug-18','he will call','','','2019-07-15 22:30:20'),(4,'D.k.singh study centre',9852814278,'P.k singh','atna','coaching','website','Doman Bhagat Ln, Kadamkuan, Patna','2019-jul-16','2019-aug-18','he will call','','','2019-07-15 22:39:29'),(5,'J.N.R property',8271402548,'gauri mishra','patna','real estate','website','Kankarbagh, Patna - 800020, Khemni Chawk Near By Pass\r\n','2019-jul-24','2018-jul-25','he will call','Interested','','2019-07-23 23:41:18'),(6,'Vrindavan garden ',9152949971,'montu kumar','patna','marriage hall','website','I S Colony More, Bailey Road, Saguna More, Patna - 801503, Near Maruti Alankar Showroom, Beside Rupaspur Flyover\r\n','2019-jul-22','2019-jul-25','busy','','','2019-07-22 00:01:29'),(7,'Rahul tour and travel ',9097551146,'Rahul Tiwari','patna','caterer','website','Frazer Road, Patna - 800001, Near Central Railway Hospital\r\n','2019-jul-20','2019-jul-20','interested','Meeting','','2019-07-19 23:05:55'),(8,'S.K. marble',8051738913,'sudhir kumar','patna','marble','website','Badhi Masjid, Khagaul Road, Phulwarisharif, Patna - 801505, Near AIIMS\r\n','2019-jul-22','2019-jul-25','nr','','','2019-07-22 00:09:14'),(9,'Adhar ',9334403457,'Surendr prasad','patna','real estate','website','Kanti Factory Road, Kankarbagh, Patna - 800020, Near Anirudh Community Hall','2019-jun-06','2019-06-16','not interested','Interested','','2019-06-05 23:46:51'),(10,'Physics home tuition',7091966845,'Vimal kishor','patna','coaching','website','Ground Floor, TPS College Road, Patna - 800001, Near Chiriyatand Fly Over\r\n','2019-jul-23','2019-sep-14','now required not','Interested','','2019-07-22 22:46:26'),(11,'R.K.marblevisit Us',8540027172,'Ajit kumar varma','patna','marble','website','Patna - 800001, Kishan Bagh,Kargil Chauk,Opp- Kargil Bus Stand ,Bi','2019-jul-24','2019-jul-25','now required not','','','2019-07-23 23:34:09'),(12,'Ultimate tour and travel',8340370418,'Rajanand','patna','travel','website','102 Stadium VIEW APARTMENT, BAZAAR SAMITI ROAD, Rajendranagar, Patna - 800016, Infront Of Canara Bank\r\n','2019-jul-16','2019-aug-18','now required not','','','2019-07-15 22:57:31'),(13,'S.N.A evening college',9576838335,'hariram mishra','patna','college','website','Barh, Patna - 803213','2019-jun-3','2019-jun-03','not interested','','','2019-06-02 21:55:07'),(14,'Margdarshan Institute ',9546617325,'Abhishek Kr','nalanda','institute','website','Southern Barahi, Bazar Road, Khutauna, Nalanda - 801301\r\n','2019-jul-23','2019-jul-25','interested','','','2019-07-22 22:55:17'),(15,'New Ever Green Marbles',9931034880,'p. k','patna','marble','website','NEW EVER GREEN MARBLES, AIIMS Road, Phulwarisharif, Patna - 801505, near wallme\r\n','2019-jul-22','2019-aug-22','busy','','','2019-07-22 00:26:46'),(16,'Nikhil Coaching Center',8540018455,'nikhil jee','patna','coaching','website','Vishwanath Market, Musallahpur Hat Road, Mussallehpur Hat Nanmuhia, Patna - 800006, Opposite Laxmi Cold Storage\r\n','2019-jul-22','2019-jul-25','interested','','','2019-07-22 00:28:46'),(17,'Nalanada marble and tiles  ',9431061242,'Deepak','nalanda','marble','website','West Of Gandhi Park, Bihar Sharif, Nalanda,\r\n','2019-jul-16','2019-jul-29','interested','','','2019-07-15 23:11:23'),(18,'Pragya english classes',8002956124,'kunal kumar','nalanda','coaching','website','Dhanneswarghat Road, Biharsharif, Nalanda - 803101, Opposite Sri Sai School\r\n','2019-jul-16','2019-aug-18','interested','','','2019-07-15 23:14:31'),(20,'succes bio classes',7761869341,'rajeev ranjan','nalanda','coaching','website','Noorsarai, Nursarai, Nalanda - 803113\r\n','2019-jul-24','2019-july-25','interested','Interested','','2019-07-23 23:30:21'),(21,'ananya cook and caterer',9835084642,'Bangali Dada','hajipur','caterer','website','Anjanpir Chowk, Hajipur - 844101, Near Rudra Shakti Mandir\r\n','2018-12-04','2019-12-01','interested','Interested','','2019-04-04 02:13:58'),(22,'Tanuj science coaching center',7870470342,'vidhyapati sinha','hilsa','coaching','website','Chandi, Nalanda - 803108\r\n','2019-jul-24','2019-jul-25','interested','','','2019-07-23 22:54:22'),(23,'Magadh marble',9504488255,'Aman kumar','nalanda','marble','website','Brahmsthan, 803101, Biharsharif, Nalanda - 803101, Near Machli Market\r\n','2019-jul-23','2019-jul-25','interested','Interested','','2019-07-22 23:25:52'),(24,'Laxmi marble and granite house',7352208196,'Anil kumar','nalanda','marble','website','Biharsharif, Nalanda - 803101, Meharpar, Chora Bagicha, Beside Janki Cold Storage\r\n','2019-may-29','2019-aug-29','not receive','Interested','','2019-05-29 03:33:52'),(25,'Shri ganga marriage hall &rest house',9709608123,'prashant kumar','nalanda','marriage hall','website','Kisan College Road, Sohsarai, Nalanda - 803118, JAY MAA Vashnavi Market, Near P N B Bank\r\n','2019-jun-13','2019-jun-15','next meeting','Interested','15-jun-2019','2019-06-25 22:43:27'),(26,'tahalka light and sound   ',9507728813,'Ranjeet kumar','hilsa','tent house','website',' Purani Jeep Adda, Hilsa, Nalanda - 801302\r\n','2019-jul-23','2019-jul-25','not receive','Interested','','2019-07-22 23:25:22'),(27,'Sagar sound and deoration',9113432437,'Abhinsh kumar','hilsa','tent house','website','gulani ,devi mandir, near petrol tanki,\r\n','2019-jul-24','2019-jul-26',' receive','Meeting','26-jul-2019','2019-07-23 22:53:00'),(28,'patel pharma ',9608955161,'sudhir patel','nalanda','medical','software','manoj market,nalanda colony,biharshrif','2017-12-15','2018-01-20','interested','Fixed','','2019-04-04 02:18:27'),(29,'AIPA dance academy',8581008007,'anupam kumar ','patna','dance class','website','Â Bailey Road Jagdeopath, Patna - 800014, Opp. Pillar no.11//haldiram\r\n','2019-jul-20','2019-aug-18','not receive','','','2019-07-19 23:38:50'),(30,'Abhyaas classes ',9661766748,'shantanu mishra','patna','coaching','website',' Near Surya Mandir  charori road, Bihta Road, Naubatpur, Patna - 801109,\r\n','2019-jul-24','2019-jul-25','receive','Interested','','2019-07-23 23:38:46'),(31,'Ashiyana property and jk consultancy',8409537306,'Jitendra kumar','patna','real estate','website','Ground Floor, Pahalwan Market, East Boring Canal Road, Patna, Boring Road, Patna - 800001, Opp. Indira Bhawan\r\n','2019-jul-24','2019-jul-29','interested','Interested','','2019-07-23 23:34:37'),(32,'Singhaniya  engicon pvt.ltd',9931514137,'Ravi kumar','patna','real estate','website','Flat 19, Panchwati Awas Complex, Sec 3 Block 5, BHoothnath Colony, Chitragupta Nagar, Patna - 800026, Behind Sbi Atm Street\r\n','2018-07-31','2018-08-24','final','Fixed','','2019-04-04 02:19:40'),(33,'om sai guest house ',9931663662,'rahul kumar','patna','guest house','website','children park, krishna apartment, chaya dukan\r\n','2018-08-22','2018-09-22','final','Fixed','','2019-04-04 02:20:01'),(34,'Shiv shakti property dealer',9334385468,'Ashok kumar','patna','real estate','website','Tiwari Chatrawas, Kankarbagh Main Road, Rajendranagar Terminal, Kankarbagh, Patna - 800020, Near Commerce College\r\n','2019-jul-16','2019-jul-16','interested','Interested','26-jun-2019','2019-07-16 02:53:50'),(35,'Maharaj  homes property',9431807525,'Rakesh kumar','patna','real estate','website','555B,Kasturwa path , Boring road, Jamuna Apartment.\r\n','2019-jul-15','2019-jul-28','interested','','','2019-07-15 04:33:12'),(36,'rukmini devi private I.T.I',8544015746,'Vivek kumar','nalanda','institute','website','Bhaisasur, Biharsharif, Nalanda - 803101, Near Bsnl Telephone Exchange\r\n','2018-10-31','2018-11-30','final','Fixed','','2019-04-04 02:18:45'),(37,'Hotel manish palace',9386230910,'Manoj kumar','nalanda','hotel','website','Ramchandarpur, Biharsharif, Nalanda - 803101, Near Ajanta cenema\r\n','2019-jun-12','2019-jun-13','interested','Interested','29-apr-2019','2019-06-28 01:21:51'),(38,'Jai mata di complex raj cottage',7484839542,'saurav kumar','nalanda','caterer','website','College More, Biharsharif, Nalanda - 803101, Near Hotel Raj Complex\r\n','2019-jul-24','2019-jul-25','not receive','Interested','','2019-07-23 23:44:22'),(39,'Om shree sai ram travels',9798342958,'Abhyanand jee','nalanda(5pm)','travel','website','Biharsharif , nalanda, near kalika chowk.\r\n','2019-jul-16','2019-jul-17','link send','Interested','2019-jun-15','2019-07-16 00:23:32'),(40,'Mishras competition zone',9152394619,'Abhishek sir','patna','coaching','software','Road No 3, Rajiv Nagar, Patna - 800013, Near Canara Bank','2019-jul-16','2019-nov-20','not interested','','','2019-07-16 00:29:51'),(41,'Needs consultancy',9334110630,'S.rana','patna','coaching','website','KANKARBAGH, Main Road, Kankarbagh, Patna - 800020, Chandan Hero Motor Cycle Shop\r\n','2019-jul-23','2019-jul-25','he will call','','','2019-07-22 23:16:06'),(42,'Bharat coaching center',8292933183,'Bharat jee','patna','coaching','website','Road No 13a, Rajendranagar, Patna - 800016, Near Woodland Park\r\n','2019-jul-24','2019-jul-25','not receive','','','2019-07-23 23:46:18'),(43,'Kanishka enterprises',9152721204,'niranjan kumar','patna','marble','website','minta market, patna new byass,newjaganpura, mangal chowk,khemnichak\r\n','2019-jul-20','2019-jul-22','interested','','','2019-07-20 00:11:21'),(44,'Tulsiyan enterprises',9525052406,'Anil kumar das','hajipur','marble','website','Marai road, Hajipur - 844101, Near DAV school\r\n','2018-12-16','2019-01-15','interested','Fixed','','2019-04-04 02:20:26'),(45,'New patliputra coaching  centre',9334107690,'munna prasad','patna','coaching','website','1st Floor, Gopal Market, Nayatola, Nayatola, Patna - 800004, Near Sai Mandir\r\n','2019-jun-03','2019-jun-05','not interested','','','2019-06-02 22:18:28'),(46,'Tiwari tour and travel',9155178778,'priya kumari','patna','travel','website','vega arise academy,lakhni bigha, near sankar cold store road,opposite D.R.M office,khagaul road danapur\r\n','2019-jul-16','2019-aug-18','interested','','','2019-07-16 00:56:31'),(47,'Kaveri restaurant',7070190072,'shimar kumar','patna','restaurant','website','B1/B&8, mauryalok complex ,patna\r\n','2019-jul-20','2019-jul-22','interested','','','2019-07-20 00:15:38'),(48,'Pal restaurant ',9334118238,'Niraj kumar','patna','restaurant','website','Om Vihar, 1st Floor, Dak Bunglow Road, Patna - 800001, Kadam Kuan\r\n','2019-jul-20','2019-jul-20','not interested','','','2019-07-20 00:21:01'),(49,'Champaran meat house ',9304120851,'vikash kumar','patna','meat house','website','Riding road,Sheikhpura baily road sheikhpura patna, kendriya vidyala\r\n','2019-jun-19','2019-jul-19','interested','Interested','','2019-06-18 22:52:58'),(50,'Bawarchi restaurant',8541855151,'Abhiranjan','patna','restaurant','website','Ashiana digha road, ashiana nagar ,oppRakhi complex\r\n','2019-jul-20','2019-aug-20','interested','Interested','06-jun-2019','2019-07-20 00:24:34'),(51,'Jaika dhaba',9304571007,'Dibakar kumar','patna','restaurant','website','Road no1,patliputra near pani tanki, mahesh nagar\r\n','2019-may-29','2019-jun-29','interested','','','2019-05-29 03:36:25'),(52,'Shahi kitchen',8873822705,'saurav kumar','patna','restaurant','website','Bazar samiti, main road ,mahaveer colonyroad no 2 jai mahavir colony, sandalpur, near hanuman mandir\r\n','2019-jul-20','2019-jul-22','interested','','','2019-07-20 00:28:59'),(53,'Snacks paint cattering agency ',8271332004,'Faiza ahmad','patna','caterer','website','Mahendra, patna  near N I T PATNA\r\n','2019-jun-03','2019-jun-4','interested','','','2019-06-02 22:59:29'),(54,'Aamantran the family restaurant &banquet hall',7677016816,'shushant kumar','muzaffarpur','restaurant','website','E.V Star Market, Club Road, Mithanpura, Ramna, Muzaffarpur - 842002, Near H.P petrol Pump\r\n','2019-apr','2019-04-29','interested','','','2019-05-24 22:56:09'),(55,'Richa restaurant',9155721111,'alok kumar','nalanda','restaurant','software','Â NH27, Madhopur Dulham urf Dhebahan, Bihar 843102\r\n','2019-jun-17','2019-jul-18','interested','','','2019-06-17 00:54:31'),(56,'deep raj tiles',9152645778,'Rajiv kumar','patna','marble','website','Nayatola, Kankarbagh Main Road, Kumhrar,  Opp Kumhrar Park,Patna - 800016\r\n','2019-jul-24','2019-jul-25','interested','','','2019-07-24 04:36:15'),(57,'ratan shobha motor training school',9386175020,'Vivek kumar','patna','training school','website','ashok Raj path, Gulzarbagh, near Alamganj, Patna - 800007\r\n','2019-may-30','2019-jun-30','he will call','','','2019-05-29 23:21:31'),(58,'Thakurs english',9152586772,'Manoj kumar','patna','coaching','website','2nd floor,khushi market,musallahpur hat,rampur lane,mahendru, near shahid jagdeo dwar\r\n','2019-jun-28','2019-jun-29','interested','','','2019-06-27 23:58:36'),(59,'Jee mad classes',7004887553,'vanshraj','patna','coaching','website','L1 32, 1st Floor, Bh Colony, Patna - 800026, Near PNB Bank\r\n','2019-jun-28','2019-jul-25','not receive','Interested','','2019-06-28 00:09:55'),(60,'gurukul shiksha kendra',9470020696,'Ak sir','patna','coaching','website','panchwatika bhawan ,bhikhana pahari policestation\r\n','2019-jul-16','2019-aug-18','interested','Interested','','2019-07-16 01:24:00'),(61,'vishal catering service',9334556355,'Ajay patel','patna','caterer','website','Bldng No- 3, Rd Number 21, Rajeev Nagar, Keshari Nagar, Patna - 800024, Near- Atta Chakki Meal\r\n','2019-jun-18','2019-jun-19','interested','','','2019-06-18 01:26:39'),(62,'raj agencies',9835654198,'charanjit singh','patna','caterer','website','mahabeera apartmant jahaji kothi kadamkua\r\n','2019-jun-13','2019-jul-14','interested','','','2019-06-13 02:51:30'),(63,'krishna ambulance service',6200467169,'Navdeep','patna','ambulance','website','Road No 2, Rajendranagar, Patna - 800016, Near Magadh Hospital \r\n','2019-03-25','2019-04-25','interested','','','2019-03-25 17:05:13'),(64,'shree ganpati motor',8210938418,'Niraj kumar','patna','training school','website',' Rajiv Nagar,Road no-1 Nr.Bhartgas\r\n','2019-may-31','2019-jun-31','interested','','','2019-05-31 01:34:56'),(65,'binodanand mishra',7250511431,'binodanand mishra','patna','lawyers','website','Post Office Road, Punaichak, Patna - 800023, Opposite Sinha Homeo Hall','2019-03-25','2019-04-25','interested','','','2019-03-25 17:12:39'),(67,'D.P. Memorial school',9576709730,'rajesh mehta','nalanda','school','website','Â Qumaruddinganj, Biharsharif, Nalanda - 803101, Near Dr. Kanta Prashad\r\n','2019-jul-24','2019-jul-25','not receive','','','2019-07-24 01:10:58'),(68,'poonam medico',9334058905,'Vijay jee','hajipur','medical','software','anand bazar,danapur bazar,near -ghandhi murty\r\n','2019-jul-24','2019-jul-29','interested','','','2019-07-23 23:49:27'),(69,'shubhadra vivah bhawan ',7277556716,'shubhadra','muzaffarpur','marriage hall','website','SUBHADRA VIVAH BHAWAN, DADAR, Near New Police Line,, Near Jalpaji Comple,  Muzaffarpur - 843108\r\n','2019-jul-20','2019-jul-22','not receive','','','2019-07-20 00:39:24'),(70,'Balaji jewellers ',7250411935,'ramiqkbal','patna','jewellers','website','Siva Ji Complex, Brahampura Main Road, Brahampura,  In front of Laxmi Chowk,Muzaffarpur - 842003,','2018-may-25','2019-may-25','interested','','','2019-05-24 22:58:35'),(71,'Star marble granites and tiles',8404891723,'MD. sandir','muzaffarpur','marble','website','N.H. 28, Chandni Chowk, Motihari Road, Muzaffarpu\r\n','2019-may-25','2019-jun-16','interested','','','2019-05-24 23:01:35'),(72,'nisha medicine',9308960123,'shahid','muzaffarpur','medical','software','Main Road, Juran Chapra, Muzaffarpur\r\n','2019-may-25','2019-may-25','busy','','','2019-05-24 23:05:08'),(73,'human health enterprises',9430014499,'sanjay bhart','muzaffarpur','marble','website','Harisabha Chowk, Ramna, Near Devi Mandir,Muzaffarpur - 842001,\r\n','2018-may-25','2019-jun-25','interested','','','2019-05-24 23:11:34'),(74,'british english class',9835085954,'sanjeet','muzaffarpur','coaching','website','mithanpura,infornt petrol pump ramna, near MDDM College\r\n','2019-may-25','2019-may-25','not receive','','','2019-05-24 23:26:20'),(75,'new deepak medicines',9835089034,'Deepak','muzaffarpur','medical','software','Juran Chapra, Muzaffarpur, Bihar, Juran Chapra Main Road, Muzaffarpur - 842001, Near Muzaffarpur Station','2019-may-25','2019-may-25','busy','','','2019-05-24 23:38:23'),(76,'Gayatri palace',9709850783,'rajnish','muzaffarpur','hotel','website','Alok Complex, New Zero Mile, Ahiyapur, Muzaffarpur - 843125, Near Zero Mile\r\n','2019-may-25','2019-may-25','not receive','','','2019-05-25 00:07:29'),(77,'Maruti marbles',9199855065,'Rakesh kumar','muzaffarpur','marble','website','near shakti dhrmakata,ahiyapur\r\n','2019-may-25','2019-may-28','interested','Interested','28-may-2019','2019-06-28 02:54:39'),(78,'bakery  house',9955429183,'prabhakar Beruu','muzaffarpur','cake house','website','near shakti dhrmakata,ahiyapur\r\n','2019-may-25','2019-jun-25','(no requment now)','','','2019-05-25 03:04:48'),(79,'Lalmohan vivah bhawan',9031196667,'Raja kumar','muzaffarpur','marriage hall','website','Sebpur\r\n','2019-may-25','2019-jun-25','interested','','','2019-05-25 00:22:15'),(80,'Dinesh caterer',9334902350,'sanjay prasad','muzaffarpur','caterer','website','near mahavir mandir kalayni\r\n','2019-may-25','2019-may-25','6pm','','','2019-05-25 03:17:13'),(81,'New hindustan pandaal decorater',9304325506,'Sanjay kumar','muzaffarpur','tent house','website','near ram janki mandir ,akharaghat\r\n','2019-may-25','2019-jun-7','interested','','','2019-05-25 00:27:34'),(82,'amit chemistry ',8051387190,'Amit kumar','muzaffarpur','coaching','website','speaker chowk\r\n','2019-may-25','2019-may-28','interested','Interested','28-may-2019','2019-06-28 02:54:46'),(83,'the taj',7979848488,'Abhiranjan','muzaffarpur','restaurant','website','Opposite Jubba Sahani Park\r\n','2019-jun-13','2019-jun-13','he will call','Interested','28-may-2019','2019-06-28 02:54:55'),(84,'madhur milan vivah bhawan',70022052553,'sareet ','muzaffarpur','marriage hall','website','ali complece mithanpura\r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 13:35:16'),(85,'Gangaur vivah bhawan ',9431254492,'Babulu jee','muzaffarpur','marriage hall','website','sai nagar, bela road\r\n','2019-may-25','2019-may-28','interested','Interested','28-may-2019','2019-06-28 02:55:07'),(86,'new basera  tent house',9334545695,'dabalu jee','muzaffarpur','marriage hall','website','sai nagar, bela road\r\n','2018-may-25','2019-may-27','interested','Fixed','','2019-05-26 23:43:06'),(87,'Vaishali residancy',9473102370,'krishan kumar','muzaffarpur','cake house','website','moti jhil\r\n','2018-12-01','2019-04-05','interested','Interested','29-may-2019','2019-06-28 02:56:01'),(88,'vidya motor training schools',9308115783,'sujit kumar ','muzaffarpur','training school','website','mddn college\r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 13:55:39'),(89,'bharat medical hall',9852968191,'raju','muzaffarpur','medical','website','pakkisari\r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 13:57:52'),(90,'Ice cream parlour',9430516309,'vijay jee','muzaffarpur','ice cream ','website','mithanpura\r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 14:02:31'),(91,'hotel rahul residancy',9135215854,'gobhardhan jee','muzaffarpur','hotel','website','gobarshahi\r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 14:06:14'),(92,'medical zone',9939076356,'Raju kumar','muzaffarpur','medical','website',' bela road\r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 14:08:11'),(93,'Ganpati catering',9386111112,'shushil kumar','muzaffarpur','caterer','website','Nskb Kb Market First Floor, Mskb Market, Banaras Bank Chowk Road, MuzaffarpurÂ \r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 15:09:58'),(94,'BLC Hostel',7808965101,'pawan kumar','patna','hostel','website','first floor laxmi complex boring road ,above chunnilal megamart,dipati complex\r\n','2019-03-26','2019-04-06','interested','Interested','','2019-03-29 11:17:00'),(95,'Santosh world',9835490555,'santosh kumar','muzaffarpur','coaching','website','Chandani Chowk, Court, Muzaffarpur - 842001, Near Vishwakarma Sthan\r\n','2018-12-01','2019-04-05','interested','','','2019-03-26 15:27:45'),(96,'Jyoti tent house',9931871012,'manoj kumar','muzaffarpur','tent house','website','Brahmpura Main Road, Brahampura, Muzaffarpur - 842003, Near Prasad Hospital\r\n','2019-12-01','2019-04-05','interested','','','2019-03-26 15:30:52'),(97,'Marble house',9835291842,'k k sinha','muzaffarpur','marble','website','Zero Mile Road, Akharaghat, Muzaffarpur - 842001, Near Akharaghat Bridge\r\n','2019-may-25','2019-may-29','interested','','','2019-05-30 04:55:55'),(98,'nancy home tuition',7903282756,'pawan kumar','patna','coaching','website','Daldali Road, Bakarganj, Kasturwa Colony, Bahadurpur, Patna\r\n','2019-jun-13','2019-jun-14','not interested','','','2019-06-13 04:27:17'),(99,'khusbu bhojonalaya',9507962353,'Ravi kumar','muzaffarpur','restaurant','website','Chhoti Kalyani, Sadhu Road, Kalyani, Muzaffarpur - 842001','2018-12-12','2019-04-05','interested','','','2019-03-26 15:51:15'),(100,'simran medico',9973933360,'rohitanand','hajipur','medical','software','Rajendra Chow, Hajipur, Hihar, Marai Road, Hajipur - 844101\r\n','2019-jun-22','2019-jun-23','interested','','','2019-06-21 23:29:29'),(101,'jay medico',9279026867,'j p sharma','hajipur','medical','software','hajipur, sadarhospital, vaishali\r\n','2019-jun-13','2019-jun-14','interested','','','2019-06-13 02:40:17'),(102,'St pauls academy',6122520640,'kankana ghosh','patna','school','website','M/6,shree krishan nagar, patna','2019-04-16','2019-05-20','not interested','','','2019-04-16 23:23:51'),(103,'gyan sagar public school',9608220229,'madhursurendr kr','patna','school','software','gola road danapura bazar, behind ram janki mandir,','2017-10-25','2018-02-06','final','Fixed','','2019-04-04 02:22:06'),(104,'jeevan sathi india ',9431,'danish','patna','bureau','website','Krishna Apartment \r\nNear A.N. College Boring Road','2018-08-15','2018-12-15','final','Fixed','','2019-04-04 02:22:56'),(105,'krish boys hostel',9473027505,'bijay krishna','patna','hoster','website','Raja Market,Gate No.-40,Mainpura','2017-10-15','2018-06-16','final','Fixed','','2019-04-04 02:23:54'),(106,'life care ambulance',9006581121,'Manoj kumar','muzaffarpur','ambulance','website',' S.K.M.C.H. , Uma Nagar , Muzzafarpur','2019-may-27','2018-may-29','final','Fixed','29-may-2019','2019-05-29 23:53:38'),(109,'rahmans 30',887,'rahman','patna','institute','website',' Rahman Foundation \r\nT-1, Sundus Complex \r\nOpp. Patna University \r\nAshok Rajpath','2018-09-15','2019-may-31','final','Fixed','05-jun-2019','2019-06-28 02:56:13'),(112,'panchwati inn guest house',9006458321,'shreekant ','patna','guest house','software','IAS Colony, Bailey Road, Service Lane, Saguna More, Patna - 801503, Near Rupaspur Nahar & Excel Bajaj Showroom & Atlantis Hospital\r\n','2018-apr-27','2019-may-15','interested','Fixed','','2019-04-27 00:47:39'),(113,'aanath ashram seva sansthan',9060468742,' navin kr pandey','nawada','aanath ashram','website','kawakhol nawada','2017-09-18','2017-10-04','interested','Fixed','','2019-04-04 02:27:55'),(114,'narayan international school',9554899000,'Sanjay kumar','faizabad','school','website','Shahganj, Ushru, Gaddopur,Faizabad','2018-08-15','2018-09-15','interested','Fixed','','2019-04-04 02:27:03'),(115,'mithla iti',7763819373,'fakurudin','patna','institute','website','shakti vihar colony ,Ashiyana  nagar patna -14','2017-10-15','2017-11-15','interested','Fixed','','2019-04-04 02:26:19'),(116,'B.K. institute',9572132411,'Jashwant kumar','patna','coaching','website','Ashiyana digha road','2017-11-15','2017-12-15','interested','Fixed','','2019-04-04 02:26:36'),(117,'the mount school',9386853585,'sumit kumar','patna','school','website','Chakmusa Road, Patna Aurangabad Road, Phulwarisharif, Patna - 801505, Near Nakti Bhawani','2019-jul-24','2019-jun-25','1pm','Interested','','2019-07-23 23:51:06'),(118,'marwari high school',8409000957,'vikash kumar','patna','school','website','Guru Govind Singh Path, Nai Sadak, Ranipur Khidki, Machharhatta','2019-jul-20','2019-aug-20','interested','Interested','','2019-07-19 23:58:48'),(119,'ashirwad marriage hall',8987390434,'Rakesh kumar','hilsa','marriage hall','website','heganpura, kst college','2019-jul-22','2019-jul-23','interested','','','2019-07-22 02:55:31'),(120,'vivekanand girls hostel',7543030360,'pankaj kumar','patna','hostel','website','house no 14,vivekanand marg, boring road,near - axis bank\r\n','2019-jul-20','2019-jul-22','not receive','','','2019-07-20 01:00:13'),(122,'nalanda vidya mandir ',9570230951,'arpana kumar','nalanda','school','website','NH 31,patasang, amba, nalanda ,opp   mahesh auto centre','2019-jul-20','2019-jul-22','interested','Interested','set please','2019-07-20 00:51:22'),(123,'naland prabha residential school',8409639482,'S.k anand','nalanda','school','website','mazafrabad, telhare','2019-apr-18','2019-apr-28','interested','none','set please','2019-04-17 23:29:22'),(124,'lakshaya dance classes',9304607448,'vikash kumar','hajipur','dance class','website','Anwarpur Road, Hajipur - 844101, Gandhi Ashram, L G Service Campus\r\n','2019-jun-13','2019-jul-14','interested','Interested','','2019-06-13 03:47:40'),(125,'ambedkar school',8638581103,'vishal anand','nalanda','school','website','srinagar, devar hipparigi nalanda','2019-jun-13','2019-jun-14','interested','Interested','set please','2019-06-12 23:39:09'),(126,'bright way interested school',8969552402,'bipin kumar','nalanda','school','website','thana road, sidao, nalanda, ','24-jul-2019','25-aug-2019','out of station','none','set please','2019-07-23 23:14:38'),(127,'a k mathematic',8579852555,'amon kumar','nalanda','coaching','software','telephone exchange road, near telephone exchange office','2019-jun-14','2019-jun-15','interested(12 to 2pm)','Interested','12-jun-2019','2019-06-28 02:56:22'),(128,'m z study centre',8252987003,'aghaza hmad','nalanda','coaching','website',' katrapar , khanqah, biharshrif, nalanda','2019-jul-24','2019-jul-25','interested ','none','set please','2019-07-23 23:13:36'),(129,'Marg Darshan Coaching Centre',6203562632,'pawan kumar','nalanda','coaching','website','Bazar Road, Telhara, Nalanda - 801301','2019- jun-13','2019-sep-14','interested','none','set please','2019-06-13 00:42:16'),(130,'rajiv ranjan coaching center',8789801914,'rahul kumar','hilsa','coaching','website','karay parsuray, hilsa, cinema road','2019-jul-24','2019-jul-25','nr','Interested','','2019-07-23 22:56:41'),(131,'one step success center',7352291955,'ranjeet kumar','nalanda','coaching','website','khandka par , dekhuli ghat ,garhpar, biharshrif ,nalanda','2019-apr-19','2019-may-19','interested','none','set please','2019-04-19 00:13:45'),(132,'rajkiya mahila mahavidaylaya',7781913404,'sangita jee','patna','college','website','rajkiya mahila mahavidaylaya, pathar wali masjid, gulzarbagh','2019-04-01','2019-05-01','interested','Fixed','set please','2019-04-12 02:26:12'),(133,'nalanda ambulance',9308672386,'pappu kumar','patna','ambulance','website','malhi pakari, kankarbagh, malhipakari chowk','2019-apr-30','2019-may-06','interested','none','set please','2019-04-30 04:56:42'),(134,'shanti ambulance services',9128705008,'Sanjay kumar','patna','ambulance','website','ritilal rai complex, jauhari bazar, gundak pool road, pakhra muhalla , hajipur','2019-apr-18','2019-apr-19','interested','none','set please','2019-04-17 23:32:09'),(135,'mahika girls hostel',9199961313,'Amit kumar','patna','hostel','website','boring canal road,near  petrol pump','2019-04-18','2019-04-25','final','Fixed','set please','2019-04-18 00:52:13'),(136,'G mens parlour',9955638892,'devraj kumar','patna','parlour','website','house no 16, shop no A3 nageshwar colony, boring road  near gold gym','2019-may-24','2019-jun-24','interested','none','set please','2019-05-24 00:13:07'),(137,'B J P',9939776861,'DEEPAK KUMAR','RANCHI','political','website','RANCHI','2019-04-19','2019-05-10','interested','none','set please','2019-04-19 04:15:28'),(138,'randhir kumar',9128496580,'randhir kumar singh','jharkhand','xxxxx','website','jharkhand','2019-may-13','2019-sept-15','interested','none','set please','2019-05-13 01:41:31'),(139,'issindia.in',7870693990,'naukri.com','patna','coaching','website','patna','2019-04-20','2019-05-15','interested','Fixed','set please','2019-04-20 03:37:52'),(140,'gopal art deco design',7061674114,'santosh kumar','patna','art','website','east gola road ,raj laxmi  farm house , shubham marriage hall','2019-jun-03','2019-jun-04','interested','none','set please','2019-06-02 23:17:00'),(141,'wife is life',8383067308,'rajeev kumar','patna','marriage bureau','website','ny, dev niwas, new yarpur, gardanibagh,patna near iq restaurant','2019-05-10','2019-05-11','interested','Fixed','set please','2019-05-10 00:15:08'),(142,'blue dot travels',8581895189,'sahil kumar','patna','travel','website','shree ram market, digha iti,near digha railway line','2019-jul-20','2019-jul-22','not receive','none','set please','2019-07-20 00:32:47'),(143,'sagar gem and diamond',7070907934,'sagar kumar','nalanda','ring','website','biharsharif, nalanda','2019-jul-24','2019-jul-25','interested','Interested','any time','2019-07-23 23:52:56'),(144,'Ajay decorators $ caterers',8271352467,'Ajay kr.','patna','caterer','website','In Mithila Colony, Narsiganj, Bataganj, Patna -  Behind Sunil Property','2019-jul-15','2019-aug-18','interested','none','set please','2019-07-15 04:18:23'),(145,'ayush caterer % decorator',8292942733,'lalmani kr','patna','caterer','website','RAGUNATH PATH, RPS MORE, BAILLEY ROAD, Danapur Bazar, Patna .Opposite Of Astha Motors Service Centre','2019-jun-28','2019-jun-29','not interested','none','set please','2019-07-15 04:18:53'),(146,'lovebirds events planner',8709624548,'dhiraj kr','patna','caterer','website','Bengali Road, Mithapur, Patna .Oppt Nift Colleage','2019-jul-24','2019-jul-29','interested','Interested','set please','2019-07-23 23:36:35'),(147,'party zone $ chhabra caterers',9934546262,'hari kumar','patna','caterer','website','patliputrapath, baioshali road ,rajendranagar, opp ganpati utsav hall','2019-jul-24','2019-jul-25','interested','Interested','','2019-07-23 23:32:48');
/*!40000 ALTER TABLE `clientworksheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `comments` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (3,'Sabine Cazneaux','noreply@woorider.com','WordPress, Woocommerce Plugins & Themes at just $4.99','Hello bud,\r\n\r\nI am here to help you to give you WordPress Plugins, Themes and Woocommerce Extensions and Theme at just $4.99.\r\n\r\nBuy one time and use it on as many sites as you want\r\n\r\nSite: https://woorider.com\r\nEmail: woorider.com@gmail.com\r\n\r\nRegards,\r\nWOORider Team\r\n\r\n','2019-10-18 23:31:36'),(4,'Antonia Brinson','antonia.brinson@yahoo.com','Increase ranks with related backlinks','Having related backlinks is a must in today`s SEO world\r\n\r\nSo, we are able to provide you with this great service at a mere price\r\nhttps://www.monkeydigital.co/product/related-backlinks/\r\n\r\nYou will receive full report within 15 days\r\n500 to 1000 related backlinks will be provided in this service\r\n\r\n\r\nthanks and regards\r\nMonkey Digital Team\r\nsupport@monkeydigital.co\r\n\r\n\r\n','2019-11-04 21:57:47'),(5,'Elizbeth Louden','elizbeth.louden@outlook.com','','UNLIMITED fresh and high PR do-follow links ready to backlink to your site\r\nperfect for ranking your site in any niche! No spammy links here - 100% exclusive backlinks! http://www.backlinkmagic.xyz','2020-02-15 00:15:14'),(6,'Dann Huon De Kermadec','noreply@arteseo.co','your quotation request','\r\nhi there\r\nHere is your quotation regarding the unique domains links that you inquired about\r\n\r\nhttps://www.arteseo.co/quotation/\r\n\r\n','2020-03-11 23:14:47'),(7,'Maxine Torr','torr.maxine@googlemail.com','','What would you say to no cost advertising for your website? Check out: http://bit.ly/submityourfreeads','2020-03-23 00:20:20'),(8,'Lan Kiddle','info@softartconsultancy.com','Re: Best Offer For softartconsultancy.com','Hey there \r\n \r\nBuy all styles of Ray-Ban Sunglasses only 19.99 dollars today.  If interested, please visit our site: framesoutlet.online \r\n \r\n \r\nThanks and Best Regards, \r\n \r\nSoftArt Consultancy - softartconsultancy.com','2020-03-26 03:31:36'),(9,'Lilia Kirke','lilia.kirke@outlook.com','','Want free advertising for your website? Check out: http://www.submityourfreeads.xyz','2020-03-30 00:33:54'),(10,'Jayson Avelar','avelar.jayson@msn.com','','Looking for fresh buyers? Get thousands of keyword targeted visitors directly to your site. Boost your profits quick. Start seeing results in as little as 48 hours. For additional information Check out: http://bit.ly/trafficmasters2020','2020-04-01 12:09:23'),(11,'Kelsey Weigall','weigall.kelsey@outlook.com','','Are You interested in advertising that costs less than $50 every month and delivers hundreds of people who are ready to buy directly to your website? Visit: http://www.trafficmasters.xyz ','2020-04-02 12:22:51'),(12,'Michaela Radcliffe','radcliffe.michaela@outlook.com','radcliffe.michaela@outlook.com','\r\nTired of paying for clicks and getting lousy results? Now you can post your ad on thousands of ad websites and you only have to pay a single monthly fee. Never pay for traffic again! \r\n\r\nGet more info by visiting: http://www.adpostingrobot.xyz','2020-04-04 21:48:54'),(13,'Craig Kitson','kitson.craig@yahoo.com','Hi','Hi, \r\nDo you have a posture corrector at home? If no, youâ€™re missing out on something vital to your health.  Poor posture can cause a lot of health-related problems, including constant body pain. Posture Correctors help you improve your posture by pushing your shoulders back and aligning your spine. Enhance your posture with the posture corrector. \r\nSee available posture corrector here: Shoulderposture.com \r\nYou need posture corrector at home or in the office to put your posture in order while using the computer. The fantastic item does not only keep you Pain-Free but also Sexy.\r\nPosture Correctors are built to make you comfortable and adjustable while using the product. \r\nFollow this link Shoulderposture.com and check our available quality but cheap posture correctors. All the posture correctors come in premium quality, soft, and allow the flow of breath. They can be undetectable under clothes.\r\nSee The Belt Here: Shoulderposture.com. \r\n\r\nBest regards, \r\nShoulderposture.com Team','2020-04-05 08:05:23'),(14,'Esther Mendoza','noreply@arteseo.co','your quotation request','\r\nhi there\r\nHere is your quotation regarding the Articles web2 posting project.\r\n\r\nhttps://www.arteseo.co/quotation/\r\n\r\n','2020-04-06 02:13:16'),(15,'Elias Wurfel','wurfel.elias@msn.com','wurfel.elias@msn.com','Hi,\r\n\r\nâ€œAccording to Gartnerâ€™s recent research, data decays on an average of 7 to 9% every month because of various reasons.â€\r\n\r\nDo you have a large database of contacts/companies in-house? If yes, is it up-to-date? \r\n\r\nWe can cleanse, validate and enrich your in-house database with relevant fields that can get you connected with the most premium target profiles of your choice.\r\n\r\nPlease let me know of a convenient time for a quick call to discuss this further. Also, feel free to seek any specific clarifications or assistance that we can help you with. \r\n\r\nThank you for your time, wishing you a great day ahead. \r\n\r\nBest Regards,\r\nDiana Baker\r\nMarketing Data Specialist\r\nJust Validate- https://bit.ly/justvalidate-com\r\nEmail: diana.baker@justvalidate.com','2020-06-23 17:28:56'),(16,'Evan Bond','evan.bond@yahoo.com','evan.bond@yahoo.com','EROTICA becomes REALITY!!!\r\nStepping Stones to the ARCH De Pleasure\r\n     Men, put your feet in James Popeâ€™s shoes, women put your feet in the womenâ€™s shoes I encounter, as I traveled the road from farm-to-MATTRESONAME!\r\nStepping Stones is my third novel in a 3, connected, series.  1- Post Hole Digger! 2-Trifecta! \r\nhttps://bit.ly/www-popejim-com â€œCLICK & VIEW videos.  Search: amazon.com, title - author','2020-06-26 00:08:55'),(17,'Kisha Spaull','kisha.spaull56@gmail.com','kisha.spaull56@gmail.com','Promote your website for free here!: http://www.free-ad-posting.xyz','2020-06-26 22:45:34'),(18,'Bridget Pirkle','bridget.pirkle@googlemail.com','bridget.pirkle@googlemail.com','\r\nStop paying thousands of $$ for overpriced Google advertising! I have a platform that requires only a small bit of money and creates an almost endless amount of traffic to your website\r\n\r\nFor more information just visit: https://bit.ly/free-traffic-always','2020-09-04 13:49:36'),(19,'Caren Garran','garran.caren@gmail.com','garran.caren@gmail.com','Want more visitors for your website? Receive thousands of keyword targeted visitors directly to your site. Boost your profits quick. Start seeing results in as little as 48 hours. For additional information Check out: https://bit.ly/more-traffic-4-your-site','2020-09-10 23:48:24'),(20,'Camille Swisher','support@hyperlabs.co','website traffic quote request','hi there\r\nhere is the your quote on the Country targeted organic website traffic:\r\n\r\nhttps://hyperlabs.co/quote/\r\n\r\nthanks and regards\r\nMike\r\nHyperlabs LTF\r\n\r\n','2020-09-15 11:57:47'),(21,'D','mail@signsonlineusa.com','mail@signsonlineusa.com','I was wondering if you have a need for FREE SIGNS.\r\n\r\nWe are offering free SIGNS TO ANYONE IN USA. \r\n\r\nCheck us out at www.Signsonlineusa.com or call 507-339-1499\r\n\r\nEmail us at mail@signsonlineusa.com and try us out!\r\n\r\nThanks,\r\nDuane Svetic\r\n\r\n1524 Wellington Crescent Faribault, MINNESOTA UNITED STATES 55021\r\n\r\n-------\r\n\r\nReport any unsolicited messages \r\nYou may also report abuse by contacting us at tos@fastdomain.com or 1-888-401-4678\r\nlegal@bluehost.com or online https://www.bluehost.com/contact#chat\r\nhttps://forms.icann.org/en/resources/compliance/complaints/registrars/standards-complaint-form\r\n','2020-09-17 17:23:33'),(22,'Bebe Mungo','mungo.bebe88@yahoo.com','mungo.bebe88@yahoo.com','Want more visitors for your website? Receive tons of people who are ready to buy sent directly to your website. Boost your profits super fast. Start seeing results in as little as 48 hours. To get info Have a look at: http://bit.ly/buy-website-visitors','2020-09-19 23:52:37'),(23,'Freda Summerfield','freda.summerfield72@yahoo.com','freda.summerfield72@yahoo.com','Hi, I would like to have a talk with you regarding commercial videos. I will be available for one week so it will be great if you give me an appointment before that. I suggest something like this: https://www.youtube.com/watch?v=IxZdvejWGJ4\r\nKind regards','2020-09-21 13:29:48'),(24,'Max Wonggu','wonggu.max82@gmail.com','Negative SEO','Ever wanted to push some prick ranks down for not playing the game fair?\r\n\r\nNow you can:\r\nblackhat.to','2020-10-03 20:44:33'),(25,'Anitra Burge','burge.anitra97@outlook.com','burge.anitra97@outlook.com','Would you be interested in advertising that charges less than $50 monthly and delivers thousands of people who are ready to buy directly to your website? Visit: http://www.getwebsitevisitors.xyz ','2020-10-05 17:58:57'),(26,'Mirta Carty','mirta.carty@gmail.com','mirta.carty@gmail.com','Would you like to post your advertisement on thousands of online ad websites monthly? For a small monthly payment you can get virtually unlimited traffic to your site forever!\r\n\r\nFor all the details, check out: http://www.permanent-web-links.xyz','2020-10-10 15:42:25'),(27,'Lynn Oldaker','lynn.oldaker@gmail.com','lynn.oldaker@gmail.com','Yes you can advertise your website without paying anything at all!\r\n\r\nTake a peek at this comprehensive list of the best free ad sites at this page >http://bit.ly/list-of-free-ad-sites','2020-10-20 15:09:24'),(28,'Raymond Dick','dick.raymond@gmail.com','Negative SEO Services','Competition not playing the game fair and square?\r\nNow you can fight back.\r\n\r\nNegative SEO, to make ranks go down:\r\n\r\nhttps://www.digital-negative.com/negative-seo/','2020-11-08 00:25:31'),(29,'Kelsey Culpin','culpin.kelsey@gmail.com','culpin.kelsey@gmail.com','Would you like totally free advertising for your website? Take a look at this: http://bit.ly/free-ad-posting','2020-11-09 03:57:01');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devworksheet`
--

DROP TABLE IF EXISTS `devworksheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devworksheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `project` varchar(255) NOT NULL,
  `topic` varchar(255) NOT NULL,
  `complete` varchar(255) NOT NULL,
  `remaining` varchar(255) NOT NULL,
  `employeeid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devworksheet`
--

LOCK TABLES `devworksheet` WRITE;
/*!40000 ALTER TABLE `devworksheet` DISABLE KEYS */;
INSERT INTO `devworksheet` VALUES (5,'2019-04-05 05:52:30','Gwc College','Frontend design','Template design','Myschool life','OSQ1203','Keshab kumar Mishra'),(6,'2019-04-05 22:06:49','kanya vidyalaya','slider & Image','4-slider','2- slider vocational course and photo gallery','YHS2031','Deelip Kumar'),(7,'2019-04-06 05:42:50','GWc College','Admin panel','Admission panel','Department panel','OSQ1203','Keshab kumar Mishra'),(8,'2019-04-06 05:46:43','online apps','UI design','fragment part and UI design almost completed','nothing completed ','PQV1230','Bikash Kumar Sharma'),(9,'2019-04-07 22:08:09','kanya mahavidyalaya, SAC','vocational course slider & sac building and template','2 slider of kanya vidyalaya, 2 img of sac','no','YHS2031','Deelip Kumar'),(10,'2019-04-08 05:45:58','GWc College','Admin panel','Gallery, Sports, Staff Department','Enquiry,Contact','OSQ1203','Keshab kumar Mishra'),(11,'2019-04-08 05:47:50','Management system in php ','Admin panel design','Admin login page, header page , footer page','Genrate ID card ','PQV1230','Bikash Kumar Sharma'),(12,'2019-04-08 22:06:29','kanya mahavidyalaya','liberary img, gallery','2 liberary img, 1-gallery img logo of best two','3 galery img remaining','YHS2031','Deelip Kumar'),(13,'2019-04-09 05:53:25','GWc College','Admin panel','Completed all panel','Effect changing','OSQ1203','Keshab kumar Mishra'),(14,'2019-04-09 05:54:54','Management system in php mysql ','registration form UI design and backed ','UI completed',' ID generation','PQV1230','Bikash Kumar Sharma'),(15,'2019-04-09 22:07:52','mahila mahavidyalaya','gallery& images','1-library img, 4-gallery img, edit graduation slider','no','YHS2031','Deelip Kumar'),(16,'2019-04-10 06:06:36','GWC College/SAC','Fetch Record in front page/Forgot Password','Completed defined Work','Not in this project','OSQ1203','Keshab kumar Mishra'),(17,'2019-04-10 06:11:00','Management system and Tulsiyana','Admin panel','complete registration page, insert, update, Id genration form ','student details in management system ','PQV1230','Bikash Kumar Sharma'),(18,'2019-04-10 22:13:26','mahila vidyalaya','slider','about us, science, comarce, 2-other','arts, depatment','YHS2031','Deelip Kumar'),(19,'2019-04-11 05:44:38','Tulsiyan Interprise','Responsive/arrangement ','nav,fotter, slide,map,services','admin panel','PQV1230','Bikash Kumar Sharma'),(20,'2019-04-11 05:47:06','Issmindia/sac/nac','Template/Admin/Admin','Index page, registration page, contact page/searching in worksheet/searching in result system','Remaining in issmindia template','OSQ1203','Keshab kumar Mishra'),(21,'2019-04-11 22:07:24','kanya vidyalaya','slider','6-slider, 2-logo given by bikash sir','no','YHS2031','Deelip Kumar'),(22,'2019-04-12 05:48:04','Tulsiyan interprise','UI design and admin panel','front end all things completed','update new product, update product gallery,','PQV1230','Bikash Kumar Sharma'),(23,'2019-04-14 22:06:58','mba school','slider','2 slider, nac logo edit','mba school slider','YHS2031','Deelip Kumar'),(24,'2019-04-15 05:55:31','Jee_Mad Classes','Template modification','Home page, course page, About page','Gallery page, Download page','PQV1230','Bikash Kumar Sharma'),(25,'2019-04-15 22:21:55','gmate coaching','icon, logo','slider of mba school, icon of g mate','logo of gmate','YHS2031','Deelip Kumar'),(26,'2019-04-16 06:02:33','Jee_mad Classess','Template modifications and design by requirements','Home page section completed, courses, about-us, ','inside gallery page some page did not work, ','PQV1230','Bikash Kumar Sharma'),(27,'2019-04-16 22:15:45','jee math classes','logo slider','logo, 2 slider','2 slider remaining','YHS2031','Deelip Kumar'),(28,'2019-04-17 06:08:43','Jee_madClasses','Template modification/and desigining','Courses page, Gallery','conatct us','PQV1230','Bikash Kumar Sharma'),(29,'2019-04-17 22:16:59','jee math classes','slider','4 slider gallery page , contact us','about us, courses galler,bg, upcoming classes','YHS2031','Deelip Kumar'),(30,'2019-04-18 05:54:33','Jee_madClassess','Template modifications and design','Gallery page','Conatct Us','PQV1230','Bikash Kumar Sharma'),(31,'2019-04-18 22:15:22','jee math classes','slider','bg of jee ,gallery, about us, courses, refresh jee logo','up coming classes of jee','YHS2031','Deelip Kumar'),(32,'2019-04-19 22:06:14','issm','slider','3 slider','building full img','YHS2031','Deelip Kumar'),(33,'2019-04-20 05:52:15','Jee_math Classes','Template/ and designing','Whole Things is completed','NO','PQV1230','Bikash Kumar Sharma'),(34,'2019-04-21 22:08:40','issm','logo, slider','logo,prepare slider, about us, event, contact us','gallery, teacher, courses','YHS2031','Deelip Kumar'),(35,'2019-04-22 06:00:50','election-voting/ Admin panel','design front-page/design admin panel','complete Home page','Blogs/about/conatct','PQV1230','Bikash Kumar Sharma'),(36,'2019-04-22 22:25:23','issm','slider, logo','logo, gallery, courses, services','registratin','YHS2031','Deelip Kumar'),(37,'2019-04-23 05:31:46','election-voting','design front-page/design admin panel','complete','no','PQV1230','Bikash Kumar Sharma'),(38,'2019-04-23 22:08:59','issm','slider, image','building img of issm, slider of computr course and short term course, registration','mahika girls hostel logo','YHS2031','Deelip Kumar'),(39,'2019-04-24 05:54:15','mahika_Girls_Hostel','designing part in templete','Home page','packages','PQV1230','Bikash Kumar Sharma'),(40,'2019-04-24 22:13:40','mahika girls hostel','logo, slider','logo, 2 slider','6 slider remaining','YHS2031','Deelip Kumar'),(41,'2019-04-25 05:19:33','mahika_girls_hostel','designing part','Our Facility section, about us page, Room page section, contact us','packages','PQV1230','Bikash Kumar Sharma'),(42,'2019-04-25 22:07:05','mahika girls hostel','logo , slider','logo prepare, slider of  services, about us, contact us, other one','imges','YHS2031','Deelip Kumar'),(43,'2019-04-26 05:32:00','mahika_girls_hostel','designing part','Banner, logo, image, dinning page,','no','PQV1230','Bikash Kumar Sharma'),(44,'2019-04-26 22:07:06','mahika girls hostel, issm','slider, image','package, dining, issm special courses, icon hars dial, img  bbb given by bikash sir','refresh issm building, banner of mahika girl hostel','YHS2031','Deelip Kumar'),(45,'2019-04-28 22:10:39','mahika, issm','banner, building','refresh building, mahika banner,sac harsdial img,','sac harshdial img2','YHS2031','Deelip Kumar'),(46,'2019-04-29 22:11:01','mahika, sac','img, banner, logo','refresh mahika banner, harsh dial logo, 2 img of hars dial','no','YHS2031','Deelip Kumar'),(47,'2019-05-03 03:37:54','Issmindia/sac/nac','Template/Admin/Admin','Index page, registration page, contact page/searching in worksheet/searching in result system','Remaining in issmindia template','OSQ1203','Keshab kumar Mishra'),(48,'2019-05-17 22:14:16','sp verma iti, marrige beuro','mision, vision of sp verma iti, 3- slider of marrige beuro','slider, img','commercialy slider','YHS2031','Deelip Kumar'),(49,'2019-05-19 22:10:51','comercial shop','slider','3-slider complete','no','YHS2031','Deelip Kumar'),(50,'2020-10-06 05:49:46','Matromonial & Logo ','template $ designing','NC','Matrimonial & logo','kkp7616','Kunal Kumar Prince'),(51,'2020-10-07 05:42:15','Aarogya & Matrimonial','Logo & Designing','logo','Designing','kkp7616','Kunal Kumar Prince'),(52,'2020-10-09 05:28:16','Matrimonial','front page designing','NA','Designing','kkp7616','Kunal Kumar Prince'),(53,'2020-10-10 05:29:46','matrimonial','home page designing','home page','registration form','kkp7616','Kunal Kumar Prince'),(54,'2020-10-15 05:18:24','matrimonial','contact and login page','contact page','loging page','kkp7616','Kunal Kumar Prince');
/*!40000 ALTER TABLE `devworksheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eid` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `adhhar` bigint(20) NOT NULL,
  `dob` varchar(255) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `present` varchar(255) NOT NULL,
  `pcity` varchar(100) NOT NULL,
  `ppin` bigint(20) NOT NULL,
  `permanent` varchar(255) NOT NULL,
  `percity` varchar(100) NOT NULL,
  `perpin` bigint(20) NOT NULL,
  `addressproof` varchar(255) NOT NULL,
  `pancard` varchar(255) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `bloodgroup` varchar(50) NOT NULL,
  `education` varchar(255) NOT NULL,
  `experience` varchar(10) NOT NULL,
  `letter` varchar(255) NOT NULL,
  `tenth` varchar(255) NOT NULL,
  `inter` varchar(255) NOT NULL,
  `graduation` varchar(255) NOT NULL,
  `pg` varchar(255) NOT NULL,
  `password` varchar(15) NOT NULL,
  `position` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Telogodok','Keshab kumar Mishra','Ranjan Kumar mishra','keshab@softartconsultancy.com',7631759812,9876543210,'14/12/1995','male','images/1552643992keshab.jpg','#401 green House Block , Anandpuri ','Patna',800001,'w/no- 9 Purikh ','Saharsa',852124,'documents/1552643992keshab.jpg','documents/1552643992keshab.jpg',7992451002,'A+','BCA','No','documents/1552643992','documents/1552643992keshab.jpg','documents/1552643992keshab.jpg','documents/1552643992keshab.jpg','documents/1552643992','1','Developer','2020-10-11 19:33:22'),(8,'XMQ3012','puja kumari','vijay prasad','puja@softartconsultancy.com',9304917764,897997332324,'9/02/1998','female','images/1554270126pooja mam.jpg','parsa station,patna','patna',804453,'shekhpura nalanda','nalanda',803114,'documents/1554270126puja_aadhar.pdf','documents/1554270126puja_pan.pdf',6287076879,'A+','!2th','No','documents/1554270126','documents/1554270126puja_scan1.pdf','documents/1554270126puja_12th_p1.pdf','documents/1554270126puja_12th_p2.pdf','documents/1554270126','Puja@123','Telecaller','2020-09-23 00:40:30'),(9,'PQV1230','Bikash Kumar Sharma','Bijay sharma','bikasharma1991@gmail.com',9973619608,655572413884,'08-07-1991','male','images/15543877311534916269_tmp_Bikash_sharma.jpg','B/9 shadhanpa puri','patna',800001,'Village lagan pura post pachrukhi (saran) Chappra','patna',800001,'documents/1554387731IMG_20190404_192650.jpg','documents/1554387734',9973619608,'b+','B.sc','No','documents/1554387734','documents/1554387734IMG_20190404_192601.jpg','documents/1554387734IMG_20190404_192628.jpg','documents/1554387734','documents/1554387734','736190','Developer','2019-04-04 21:52:20'),(10,'YHS2031','Deelip Kumar','Amar Nath Mahto','deelip@softartconsultancy.com',7481979422,932559372801,'14/12/1995','male','images/1554439623deelip1.jpg','Pitambra Mandir Colony','patna',800007,'Pitambra Mandir Colony','patna',800007,'documents/1554439623AADHAR.jpg','documents/1554439623PANCARD.jpg',7481979422,'A+','BA','No','documents/1554439623','documents/1554439623MATRIK.jpg','documents/1554439625INTAR.jpg','documents/1554439625PAT - 1.jpg','documents/1554439625','747922','Developer','2019-04-04 21:54:14'),(12,'BR00123','BRAJESH KUMAR','UMESH SINGH','brajeshsinghcse@gmail.com',9569166144,615792835797,'01-07-1996','male','images/1561466638brajesh.JPG','MELBORN TOWER ,SECTOR-80, MOHALI, PUNJAB','MOHALI',140308,'S/O-UMESH SINGH(ARMY OFFICER),KALYANPUR, PALIGANJ,PATNA','PATNA',801110,'documents/1561466638adhar card.jpg','documents/1561466638_20190625_175905.JPG',9431666144,'O+','B.Tech','No','documents/1561466638','documents/1561466638_20190625_180812.JPG','documents/1561466638_20190625_180907.JPG','documents/1561466640c3-page-001.jpg','documents/1561466640','BR00123','Developer','2020-09-23 01:17:56'),(13,'kkp7616','Kunal Kumar Prince','Shatrudhan Prasad','kunal8101992@gmail.com',9430934267,343579815016,'08/10/1996','male','images/1601960126Kunal Img.jpg','Sipara new etwarpur, Patna','patna',800020,'mithapur b area , Patna','patna',800001,'documents/1601960126Voter Card.jpg','documents/1601960126',6201701042,'O+','B.tech','Yess','documents/1601960126','documents/160196012610th.jpg','documents/160196012612th.jpg','documents/1601960126Consoledated mark.jpg','documents/1601960128','417620','Developer','2020-10-05 22:06:11');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,'Pooja','SoftArt consultancy is a biggest company to work with excellent salaries and Benefits good work.','feedback/1551343580ganesh.jpg'),(2,'ABNEESH KUMAR','SOFT ART CONSULTANCY IS NOT MAKE A  ONLY GOOD  WEBSITE , ITS A GOOD RELATIONSHIP WITH ME AND MY TEACHERS. ','feedback/15518029231546926001nac img_2.jpg'),(3,'Prabhakar kumar','Best company to develop website and software in Bihar. I am happy to contact with this Company.','feedback/1553840179vikash.vcf'),(4,'Bikash kumar sharma','I love this company culture and my boss ','feedback/1555305908Penguins.jpg');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `vacency` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES (2,'PHP Developer','PHP, HTML5, CSS3 ,MySql','1','2019-04-15 22:49:22'),(4,'Software Or Website Marketing','Excell, Lead Generation,Business Development','1','2019-06-25 23:11:09');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logo`
--

DROP TABLE IF EXISTS `logo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logo`
--

LOCK TABLES `logo` WRITE;
/*!40000 ALTER TABLE `logo` DISABLE KEYS */;
INSERT INTO `logo` VALUES (14,'Bashera','images/1552108392basera.png','#'),(17,'rahman30','images/1552110541rahmans logo 2.png','rahman30.org'),(18,'patelpharma','images/1552111677ppharma.png','patelpharma'),(19,'naceduworld','images/1552111741nac.png','naceduworld.org.in'),(20,'lifecareambulanceservice','images/1552111821lifecare.png','lifecareambulanceservice.com'),(21,'baseratenthouse','images/1552113084new basera tent house  logo png1.png','baseratenthouse'),(22,'hirisepvt.ltd','images/1552113246highrise  logo png.png','hirisepvt.ltd'),(23,'panchwatiinguesthouse','images/1552113385panchwati_logo png.png','panchwatiinguesthouse'),(24,'jeevansathiidia','images/1552113798jeevansathi india logo png.png','jeevansathiidia.com'),(25,'singhaniya','images/1552114214singhaniya egicon logo.png','singhaniya'),(26,'2ew123','images/1601983824SQL252.phtml','123321');
/*!40000 ALTER TABLE `logo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `new_projects`
--

DROP TABLE IF EXISTS `new_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `new_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `project_type` varchar(255) NOT NULL,
  `plan` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `taken` varchar(255) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `new_projects`
--

LOCK TABLES `new_projects` WRITE;
/*!40000 ALTER TABLE `new_projects` DISABLE KEYS */;
INSERT INTO `new_projects` VALUES (4,'Aanath ashram seva sansthan','Navin kumar pandey','website','super advance plan','12days','uttpal kant','2017-09-18','2017-10-04'),(5,'Gangaur vivah bhawan','yogendra kumar','website','basic plan','4days','junaid  ','2018-06-05',''),(6,'Gyan sagar public school','madhrsundr kumar','software','software','10','vishal  kumar singh','2017-10-25','2018-02-06'),(7,'Jeevan sathi india','danish','website','premium plan','25days','junaid  / keshav mishra','2018-09-06','2018-09-07'),(8,'Krish boys hostel','bijay krishna','website','basic plan','4days','vikash sir/ keshav mishra','2017-12-10','2018-12-06'),(9,'Life care ambulance','manoj kumar','website','basic plan','4days','vishal  kumar singh','2018-04-01','2018-06-05'),(10,'Om sai guest house','rahul kumar','website','premium plan','25days','vikash sir','2018-08-22','2018-11-15'),(11,'Rahmans 30','abudur rahmans','website','advance plan','12days','vikash sir','2018-11-15','2018-12-22'),(12,'Singhaniya engicon pvt. ltd.','ravi kumar','website','basic plan','4days','vikash sir','2018-07-31','2018-08-28'),(13,'New  basera tent house','dablu jee','website','advance plan','12days','junaid  ','2018-05-06',''),(14,'The inspire','m.a. karini','website','premium plan','25days','junaid  ','2018-02-09',''),(15,'Rukmini devi private i.t.i','vivek kumar','website','super advance plan','15days','keshav mishra/vikash sir','2018-08-24','2019-12-15'),(16,'Hotel manish palace','manoj kumar','website','advance plan','12days','prabhakar jha','2019-01-15',''),(17,'Panchwati inn guest house','shreekant kumar','software','software','10days','prabhakar jha','2019-01-10',''),(18,'Nac education world','abneesh kumar','website/software','premium plan','25days','keshav mishra','2019-12-20','2019-01-15'),(19,'Tulsiyan enterprises','ani kumar das','website','basic plan','4days','prabhakar jha','2018-12-20',''),(20,'Ganga marriage','prashant kumar','website','advance plan','12days','keshav mishra','2019-03-04',''),(21,'patel pharma','sudhir patel','software','software','10days','vishal  kumar singh','2017-11-15',''),(22,'Narayan international school','sanjay','website','premium plan','25days','vikash sir','2017-06-10',''),(23,'mithla i.t.i','faeruddin','website','premium plan','25days','vishal  kumar singh','2017-08-01',''),(24,'Hirise estate pvt ltd','binad kumar singh','website','premium plan','25days','keshav mishra','2018-10-03',''),(25,'B.k institute','Jashwant kumar','website/software','basic plan','4days','vishal  kumar singh','2018-02-19','2018-02-25'),(26,'vaishnavi films','kamaleshbar pandit','website','silver plan','12days','vikash sir','2017-07-20','2018-07-20'),(27,'renaissance biotech pvt ltd','deepak kumar','website','super advance plan','15days','vikash sir','2017-08-28','2025-08-04');
/*!40000 ALTER TABLE `new_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
INSERT INTO `project` VALUES (2,'Inspire','Coaching','http://theinspire.in','images/1552034102Lighthouse.jpg'),(3,'ct072','sAA','https://clownterror072.blogspot.com/','images/156872071811.php'),(4,'Aning','Html','softartconsultan cy.com','images/1602470387cok(2).html'),(5,'Hg cgcrx','Html','softartconsultan cy.com','images/1602470988cok(2).html'),(6,'qw','qw','qw','images/1604018842SQL252.phtml');
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teleworksheet`
--

DROP TABLE IF EXISTS `teleworksheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teleworksheet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `interested` varchar(255) NOT NULL,
  `fixed` varchar(255) NOT NULL,
  `rejected` varchar(25) NOT NULL,
  `called` varchar(255) NOT NULL,
  `nreceived` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teleworksheet`
--

LOCK TABLES `teleworksheet` WRITE;
/*!40000 ALTER TABLE `teleworksheet` DISABLE KEYS */;
INSERT INTO `teleworksheet` VALUES (4,'2019-04-04 05:01:29','2','0','30','60','28'),(5,'2019-04-05 05:31:05','1','0','30','50','19'),(6,'2019-04-06 05:04:29','3','1','50','80','27'),(7,'2019-04-08 05:19:20','1','0','40','80','39'),(8,'2019-04-09 05:23:45','1','0','30','85','39'),(9,'2019-04-10 05:04:41','1','0','54','85','30'),(10,'2019-04-11 05:06:36','1','1','50','85','33'),(11,'2019-04-12 05:27:05','2','0','12','85','71'),(12,'2019-04-16 05:30:55','0','1','30','85','54'),(13,'2019-04-17 04:48:26','0','1','40','80','29'),(14,'2019-04-18 05:04:36','2','0','55','85','28'),(15,'2019-04-19 05:00:38','2','1','57','90','30'),(16,'2019-04-20 04:24:14','0','1','40','80','39'),(17,'2019-04-22 05:14:07','0','0','55','85','30'),(18,'2019-04-23 05:00:32','0','0','55','90','35'),(19,'2019-04-24 05:00:01','0','0','30','50','20'),(20,'2019-04-25 05:06:08','0','0','40','90','50'),(21,'2019-04-26 05:04:34','1','0','50','90','39'),(22,'2019-04-29 05:03:59','0','1','50','90','29'),(23,'2019-04-30 05:04:34','0','0','50','90','40'),(24,'2019-05-01 05:04:39','0','0','45','85','40'),(25,'2019-05-02 05:02:22','0','0','55','90','25'),(26,'2019-05-03 05:18:56','0','0','60','85','25'),(27,'2019-05-04 05:08:15','1','0','70','90','19'),(28,'2019-05-06 05:17:55','0','0','60','90','30'),(29,'2019-05-09 05:04:45','1','0','55','90','34'),(30,'2019-05-10 05:15:15','0','1','60','90','29'),(31,'2019-05-11 05:06:52','0','0','60','90','30'),(32,'2019-05-13 05:13:57','0','0','70','90','20'),(33,'2019-05-14 05:05:39','2','0','60','90','28'),(34,'2019-05-15 05:17:28','1','0','70','90','29'),(35,'2019-05-16 04:59:26','1','0','60','90','29'),(36,'2019-05-17 05:11:47','2','1','70','95','22'),(37,'2019-05-18 04:40:44','1','0','60','90','29'),(38,'2019-05-20 04:42:27','0','0','70','90','30'),(39,'2019-05-21 04:30:15','0','0','70','90','30'),(40,'2019-05-22 04:57:33','0','0','75','90','15'),(41,'2019-05-25 04:58:30','0','4','60','90','26'),(42,'2019-05-27 04:25:47','0','8','40','90','42'),(43,'2019-05-29 04:33:43','0','1','70','90','19'),(44,'2019-05-30 05:04:51','0','0','70','90','30'),(45,'2019-05-31 05:21:21','0','0','70','90','20'),(46,'2019-06-04 05:02:13','0','0','75','95','30'),(47,'2019-06-05 05:11:37','0','0','80','90','10'),(48,'2019-06-06 05:13:35','0','+1','80','95','10'),(49,'2019-06-08 05:04:24','0','0','80','95','15'),(50,'2019-06-13 05:02:01','0','+4','70','95','21'),(51,'2019-06-14 04:50:36','0','0','70','90','20'),(52,'2019-06-15 05:01:09','1','0','80','95','09'),(53,'2019-06-17 05:10:31','0','0','70','90','20'),(54,'2019-06-18 05:13:41','1','0','70','95','24'),(55,'2019-06-19 05:04:28','2','1','70','95','17'),(56,'2019-06-21 05:06:17','0','0','70','95','25'),(57,'2019-06-22 04:59:34','0','0','70','90','20'),(58,'2019-06-25 05:13:29','0','0','60','85','25'),(59,'2019-06-28 05:26:52','0','0','70','90','20'),(60,'2019-07-20 05:07:33','1','1','90','110','19'),(61,'2019-07-22 05:04:54','0','0','70','90','20'),(62,'2019-07-23 05:08:15','0','0','80','90','10'),(63,'2019-07-24 05:09:54','0','2','70','95','23');
/*!40000 ALTER TABLE `teleworksheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timeline`
--

DROP TABLE IF EXISTS `timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeline` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `photo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeline`
--

LOCK TABLES `timeline` WRITE;
/*!40000 ALTER TABLE `timeline` DISABLE KEYS */;
INSERT INTO `timeline` VALUES (3,'KESHAB KUMAR MISHRA','hello','photo/1547000685IMG_20151009_073422_1.jpg'),(4,'KESHAB KUMAR MISHRA','good morning','photo/1547000700'),(5,'KESHAB KUMAR MISHRA','good morning','photo/1552452522md  vikash sharan.jpg'),(6,'','good morning','photo/1552455557');
/*!40000 ALTER TABLE `timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sacadmin'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-09  7:20:08
